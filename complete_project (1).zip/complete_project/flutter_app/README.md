# AI Fitness App — Flutter Frontend

## Setup

1. Install Flutter SDK (3.x): https://docs.flutter.dev/get-started/install
2. `cd flutter_app && flutter pub get`
3. Edit `lib/config/api_config.dart` — set `baseUrl` to your deployed PHP backend URL.
4. Run: `flutter run` (device/emulator) or `flutter build apk --release` for Play Store.

## What's included (functional, connected to backend API)

- **Splash + Auth flow**: token persistence via SharedPreferences, auto-login
- **Login / Signup**: full API integration
- **Dashboard**: health score hero card, XP/streak stats, colorful quick-action grid
- **Diet Plan screen**: fetches/generates rule-based plan, macro breakdown, meal cards
- **Workout screen + Smart Workout Mode**: exercise list + timer-based session
  (auto-advances sets/exercises, rest countdown)
- **Tracker screen**: water intake (quick-add chips + progress bar), sleep logging
- **AI Chat Coach**: full chat UI wired to Gemini backend endpoint
- **Profile screen**: user info, profile details, logout
- **Premium screen**: plan listing (Razorpay checkout is stubbed — see note below)

## Design System

`lib/config/theme.dart` implements the colorful card-based SaaS design discussed:
- Diet = green-teal gradient
- Workout = orange-red gradient
- Water = blue gradient
- Sleep/Health = purple gradient
- Gamification = gold gradient
- `GradientCard` widget reused across all screens for consistency

## Now Also Included

- **Razorpay integration**: `premium_screen.dart` calls `create_order.php` (backend)
  to get a real order_id, opens Razorpay checkout, then verifies via `verify_payment.php`.
- **AdMob widgets**: `lib/widgets/ad_banner_widget.dart` — `AdBannerWidget`,
  `InterstitialAdManager`, `RewardedAdManager`. Wrap screens with a premium check:
  `if (!isPremium) const AdBannerWidget(adUnitId: '...')`. Ad unit IDs come from the
  admin panel's Ad Control page (fetch via a small new endpoint, or hardcode per build).
- **Food Photo Analysis screen**: `lib/screens/food_photo_screen.dart` — camera/gallery
  picker, multipart upload to `/api/food_photo/analyze.php`, shows calories/macros/health score.
- **Exercise Library screen**: `lib/screens/exercise_library_screen.dart` — filter by
  category, calls new `GET /api/exercises/list.php` endpoint.
- **Dark mode**: `AppThemeDark.dark()` in theme.dart + `ThemeController` (ChangeNotifier).
  To enable a toggle: wrap `MaterialApp` with `ChangeNotifierProvider(create: (_) => ThemeController())`
  and use `context.watch<ThemeController>().theme` as the `theme:` value.

## Still To Do (final polish)

- **Push notifications**: water/streak reminders via Firebase Cloud Messaging (FCM).
- **App icon + splash branding**: use flutter_launcher_icons / flutter_native_splash.
- **google-services.json**: needed for AdMob + FCM — download from Firebase console
  after creating a project, place in `android/app/`.
- See `android_manifest_notes/README.md` for required AndroidManifest.xml changes.
