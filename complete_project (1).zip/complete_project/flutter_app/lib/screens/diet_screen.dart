import 'package:flutter/material.dart';
import '../config/theme.dart';
import '../config/api_config.dart';
import '../services/api_service.dart';
import '../models/diet_model.dart';

class DietScreen extends StatefulWidget {
  const DietScreen({super.key});
  @override
  State<DietScreen> createState() => _DietScreenState();
}

class _DietScreenState extends State<DietScreen> {
  DietPlanModel? _plan;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchOrGenerate();
  }

  Future<void> _fetchOrGenerate() async {
    setState(() => _loading = true);
    var res = await ApiService.get(ApiConfig.getDiet);
    if (res['success'] != true) {
      res = await ApiService.post(ApiConfig.generateDiet, {});
    }
    setState(() {
      _loading = false;
      if (res['success'] == true) {
        _plan = DietPlanModel.fromJson(res['data']);
      } else {
        _error = res['message'];
      }
    });
  }

  final _mealEmoji = {'breakfast': '🌅', 'lunch': '🍛', 'dinner': '🌙', 'snack': '🍎'};

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!, textAlign: TextAlign.center)));

    return RefreshIndicator(
      onRefresh: _fetchOrGenerate,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Today\'s Diet Plan', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          GradientCard(
            colors: AppColors.dietGradient,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _macroStat('${_plan!.totalCalories}', 'Calories'),
                _macroStat('${_plan!.totalProteinG.toInt()}g', 'Protein'),
                _macroStat('${_plan!.totalCarbsG.toInt()}g', 'Carbs'),
                _macroStat('${_plan!.totalFatG.toInt()}g', 'Fat'),
              ],
            ),
          ),
          const SizedBox(height: 20),
          ..._plan!.meals.map((meal) => Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Text(_mealEmoji[meal.mealType] ?? '🍽️', style: const TextStyle(fontSize: 28)),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(meal.mealType[0].toUpperCase() + meal.mealType.substring(1),
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                            const SizedBox(height: 4),
                            Text(meal.foodItems.join(', '), style: const TextStyle(color: AppColors.textMuted, fontSize: 13)),
                            const SizedBox(height: 4),
                            Text('${meal.calories} kcal • ₹${meal.estCostInr.toInt()}', style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              )),
        ],
      ),
    );
  }

  Widget _macroStat(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)),
      ],
    );
  }
}
