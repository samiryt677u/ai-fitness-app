import 'package:flutter/material.dart';
import '../config/theme.dart';
import '../config/api_config.dart';
import '../services/api_service.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatMessage {
  final String text;
  final bool isUser;
  _ChatMessage(this.text, this.isUser);
}

class _ChatScreenState extends State<ChatScreen> {
  final _controller = TextEditingController();
  final List<_ChatMessage> _messages = [_ChatMessage('Namaste! 👋 Main aapka AI fitness coach hoon. Diet, workout, ya health se related kuch bhi puchiye!', false)];
  int? _conversationId;
  bool _sending = false;

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _sending) return;

    setState(() {
      _messages.add(_ChatMessage(text, true));
      _sending = true;
      _controller.clear();
    });

    final res = await ApiService.post(ApiConfig.chatSend, {'message': text, 'conversation_id': _conversationId});

    setState(() {
      _sending = false;
      if (res['success'] == true) {
        _conversationId = res['data']['conversation_id'];
        _messages.add(_ChatMessage(res['data']['reply'], false));
      } else {
        _messages.add(_ChatMessage(res['message'] ?? 'Kuch error aaya, try again.', false));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: const [
              CircleAvatar(backgroundColor: AppColors.primary, child: Text('🤖')),
              SizedBox(width: 10),
              Text('AI Chat Coach', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _messages.length,
            itemBuilder: (_, i) {
              final m = _messages[i];
              return Align(
                alignment: m.isUser ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                  decoration: BoxDecoration(
                    gradient: m.isUser ? const LinearGradient(colors: [AppColors.primary, AppColors.teal]) : null,
                    color: m.isUser ? null : Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(m.text, style: TextStyle(color: m.isUser ? Colors.white : AppColors.textDark)),
                ),
              );
            },
          ),
        ),
        if (_sending) const Padding(padding: EdgeInsets.all(8), child: LinearProgressIndicator()),
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _controller,
                  decoration: const InputDecoration(hintText: 'Apna sawaal likhein...'),
                  onSubmitted: (_) => _send(),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(icon: const Icon(Icons.send), onPressed: _send),
            ],
          ),
        ),
      ],
    );
  }
}
