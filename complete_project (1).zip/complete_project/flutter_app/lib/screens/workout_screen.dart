import 'package:flutter/material.dart';
import '../config/theme.dart';
import '../config/api_config.dart';
import '../services/api_service.dart';
import '../models/workout_model.dart';
import 'workout_session_screen.dart';

class WorkoutScreen extends StatefulWidget {
  const WorkoutScreen({super.key});
  @override
  State<WorkoutScreen> createState() => _WorkoutScreenState();
}

class _WorkoutScreenState extends State<WorkoutScreen> {
  List<ExerciseModel> _exercises = [];
  int? _planId;
  int _estDuration = 0;
  int _estCalories = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res = await ApiService.post(ApiConfig.generateWorkout, {});
    if (res['success'] == true) {
      final data = res['data'];
      final result = data['result'] ?? data;
      setState(() {
        _planId = data['plan_id'];
        _exercises = (result['exercises'] as List? ?? [])
            .map((e) => ExerciseModel.fromJson(e))
            .toList();
        _estDuration = result['est_duration_min'] ?? 0;
        _estCalories = result['est_calories_burn'] ?? 0;
        _loading = false;
      });
    } else {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Today\'s Workout', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          GradientCard(
            colors: AppColors.workoutGradient,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('$_estDuration min', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                    const Text('Est. Duration', style: TextStyle(color: Colors.white70, fontSize: 12)),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text('$_estCalories kcal', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                    const Text('Est. Burn', style: TextStyle(color: Colors.white70, fontSize: 12)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          ..._exercises.asMap().entries.map((entry) {
            final ex = entry.value;
            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: CircleAvatar(backgroundColor: AppColors.workoutGradient.first.withOpacity(0.15), child: Text('${entry.key + 1}')),
                title: Text(ex.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text('${ex.sets} sets × ${ex.reps} reps • ${ex.restSeconds}s rest'),
                trailing: ex.videoUrl != null ? const Icon(Icons.play_circle_outline, color: AppColors.primary) : null,
              ),
            );
          }),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            icon: const Icon(Icons.play_arrow),
            label: const Text('Start Workout'),
            onPressed: _exercises.isEmpty ? null : () {
              Navigator.push(context, MaterialPageRoute(
                builder: (_) => WorkoutSessionScreen(planId: _planId, exercises: _exercises),
              ));
            },
          ),
        ],
      ),
    );
  }
}
