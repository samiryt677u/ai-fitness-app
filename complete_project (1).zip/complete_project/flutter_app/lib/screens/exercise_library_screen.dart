import 'package:flutter/material.dart';
import '../config/theme.dart';
import '../config/api_config.dart';
import '../services/api_service.dart';

class ExerciseLibraryScreen extends StatefulWidget {
  const ExerciseLibraryScreen({super.key});
  @override
  State<ExerciseLibraryScreen> createState() => _ExerciseLibraryScreenState();
}

class _ExerciseLibraryScreenState extends State<ExerciseLibraryScreen> {
  List<dynamic> _exercises = [];
  String _filter = 'beginner';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res = await ApiService.get('${ApiConfig.exercisesList}?category=$_filter', auth: false);
    setState(() {
      _exercises = res['data']?['exercises'] ?? [];
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Exercise Library')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Wrap(
              spacing: 8,
              children: ['beginner', 'intermediate', 'advanced'].map((level) {
                final selected = _filter == level;
                return ChoiceChip(
                  label: Text(level[0].toUpperCase() + level.substring(1)),
                  selected: selected,
                  selectedColor: AppColors.primary,
                  labelStyle: TextStyle(color: selected ? Colors.white : AppColors.textDark),
                  onSelected: (_) { setState(() => _filter = level); _load(); },
                );
              }).toList(),
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _exercises.length,
                    itemBuilder: (_, i) {
                      final ex = _exercises[i];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: ListTile(
                          contentPadding: const EdgeInsets.all(14),
                          leading: CircleAvatar(
                            backgroundColor: AppColors.workoutGradient.first.withOpacity(0.15),
                            child: const Icon(Icons.fitness_center, color: Color(0xFFF97316)),
                          ),
                          title: Text(ex['name'], style: const TextStyle(fontWeight: FontWeight.w600)),
                          subtitle: Text('${ex['muscle_group'] ?? ''} • ${ex['equipment']} • ${ex['default_sets']}x${ex['default_reps']}'),
                          trailing: ex['video_url'] != null ? const Icon(Icons.play_circle_outline, color: AppColors.primary) : null,
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
