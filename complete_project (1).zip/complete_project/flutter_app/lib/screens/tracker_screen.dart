import 'package:flutter/material.dart';
import '../config/theme.dart';
import '../config/api_config.dart';
import '../services/api_service.dart';

class TrackerScreen extends StatefulWidget {
  const TrackerScreen({super.key});
  @override
  State<TrackerScreen> createState() => _TrackerScreenState();
}

class _TrackerScreenState extends State<TrackerScreen> {
  int _waterMl = 0;
  int _waterGoal = 3000;
  double? _sleepHours;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final waterRes = await ApiService.get(ApiConfig.water);
    final sleepRes = await ApiService.get(ApiConfig.sleep);
    setState(() {
      _waterMl = waterRes['data']?['log']?['amount_ml'] ?? 0;
      _waterGoal = waterRes['data']?['log']?['goal_ml'] ?? 3000;
      _sleepHours = sleepRes['data']?['log'] != null ? double.tryParse('${sleepRes['data']['log']['sleep_hours']}') : null;
      _loading = false;
    });
  }

  Future<void> _addWater(int ml) async {
    await ApiService.post(ApiConfig.water, {'amount_ml': ml});
    _load();
  }

  Future<void> _logSleep(double hours) async {
    await ApiService.post(ApiConfig.sleep, {'sleep_hours': hours});
    _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    final waterPct = (_waterMl / _waterGoal).clamp(0.0, 1.0);

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Health Tracker', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),

          GradientCard(
            colors: AppColors.waterGradient,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('💧 Water Intake', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                  Text('$_waterMl / $_waterGoal ml', style: const TextStyle(color: Colors.white)),
                ]),
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(value: waterPct, minHeight: 10, backgroundColor: Colors.white30, valueColor: const AlwaysStoppedAnimation(Colors.white)),
                ),
                const SizedBox(height: 12),
                Wrap(spacing: 8, children: [
                  _quickAddChip('+250ml', () => _addWater(250)),
                  _quickAddChip('+500ml', () => _addWater(500)),
                  _quickAddChip('+1000ml', () => _addWater(1000)),
                ]),
              ],
            ),
          ),
          const SizedBox(height: 14),

          GradientCard(
            colors: AppColors.sleepGradient,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('😴 Sleep Tracker', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 8),
                Text(_sleepHours != null ? '${_sleepHours!.toStringAsFixed(1)} hours logged today' : 'Not logged yet',
                    style: const TextStyle(color: Colors.white70)),
                const SizedBox(height: 12),
                Wrap(spacing: 8, children: [
                  for (final h in [5.0, 6.0, 7.0, 8.0, 9.0]) _quickAddChip('${h.toInt()}h', () => _logSleep(h)),
                ]),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _quickAddChip(String label, VoidCallback onTap) {
    return ActionChip(
      label: Text(label, style: const TextStyle(color: Colors.white)),
      backgroundColor: Colors.white.withOpacity(0.2),
      onPressed: onTap,
    );
  }
}
