import 'dart:async';
import 'package:flutter/material.dart';
import '../config/theme.dart';
import '../config/api_config.dart';
import '../services/api_service.dart';
import '../models/workout_model.dart';

/// Smart Workout Mode: timer-based, auto-advances through exercises.
class WorkoutSessionScreen extends StatefulWidget {
  final int? planId;
  final List<ExerciseModel> exercises;
  const WorkoutSessionScreen({super.key, required this.planId, required this.exercises});

  @override
  State<WorkoutSessionScreen> createState() => _WorkoutSessionScreenState();
}

class _WorkoutSessionScreenState extends State<WorkoutSessionScreen> {
  int _currentIndex = 0;
  int _currentSet = 1;
  bool _isResting = false;
  int _secondsLeft = 0;
  Timer? _timer;
  int? _sessionId;

  @override
  void initState() {
    super.initState();
    _startSession();
  }

  Future<void> _startSession() async {
    final res = await ApiService.post(ApiConfig.startSession, {'workout_plan_id': widget.planId});
    if (res['success'] == true) _sessionId = res['data']['session_id'];
  }

  void _startRest() {
    final ex = widget.exercises[_currentIndex];
    setState(() { _isResting = true; _secondsLeft = ex.restSeconds; });
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      setState(() => _secondsLeft--);
      if (_secondsLeft <= 0) {
        t.cancel();
        _nextStep();
      }
    });
  }

  void _nextStep() {
    final ex = widget.exercises[_currentIndex];
    setState(() => _isResting = false);

    if (_currentSet < ex.sets) {
      setState(() => _currentSet++);
    } else if (_currentIndex < widget.exercises.length - 1) {
      setState(() { _currentIndex++; _currentSet = 1; });
    } else {
      _completeSession();
    }
  }

  Future<void> _completeSession() async {
    if (_sessionId != null) {
      await ApiService.post(ApiConfig.completeSession, {'session_id': _sessionId});
    }
    if (mounted) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('🎉 Workout Complete!'),
          content: const Text('Great job! XP has been added to your profile.'),
          actions: [TextButton(onPressed: () {
            Navigator.pop(context);
            Navigator.pop(context);
          }, child: const Text('Done'))],
        ),
      );
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ex = widget.exercises[_currentIndex];
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      appBar: AppBar(backgroundColor: Colors.transparent, foregroundColor: Colors.white, title: Text('Exercise ${_currentIndex + 1}/${widget.exercises.length}')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_isResting) ...[
              const Text('REST', style: TextStyle(color: Colors.white70, fontSize: 20, letterSpacing: 4)),
              const SizedBox(height: 20),
              Text('$_secondsLeft', style: const TextStyle(color: Colors.white, fontSize: 72, fontWeight: FontWeight.bold)),
              const SizedBox(height: 30),
              Text('Next: ${ex.name} — Set ${_currentSet < ex.sets ? _currentSet + 1 : 1}',
                  style: const TextStyle(color: Colors.white70)),
            ] else ...[
              Text(ex.name, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Text('Set $_currentSet of ${ex.sets}', style: const TextStyle(color: AppColors.teal, fontSize: 18)),
              const SizedBox(height: 8),
              Text('${ex.reps} reps', style: const TextStyle(color: Colors.white70, fontSize: 16)),
              const SizedBox(height: 40),
              ElevatedButton(
                onPressed: _startRest,
                style: ElevatedButton.styleFrom(backgroundColor: AppColors.teal, minimumSize: const Size(200, 56)),
                child: const Text('Set Complete ✓'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
