import 'package:flutter/material.dart';
import '../config/theme.dart';
import '../config/api_config.dart';
import '../services/api_service.dart';
import 'diet_screen.dart';
import 'workout_screen.dart';
import 'tracker_screen.dart';
import 'chat_screen.dart';
import 'profile_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _navIndex = 0;
  Map<String, dynamic>? _healthScore;
  Map<String, dynamic>? _gamification;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final scoreRes = await ApiService.get(ApiConfig.healthScore);
    final gamRes = await ApiService.get(ApiConfig.gamificationStatus);
    setState(() {
      _healthScore = scoreRes['data'];
      _gamification = gamRes['data'];
      _loading = false;
    });
  }

  final _screens = const [SizedBox(), DietScreen(), WorkoutScreen(), TrackerScreen(), ChatScreen()];

  @override
  Widget build(BuildContext context) {
    if (_navIndex != 0) return _scaffoldWithNav(_screens[_navIndex]);
    return _scaffoldWithNav(_buildHome());
  }

  Widget _scaffoldWithNav(Widget body) {
    return Scaffold(
      body: SafeArea(child: body),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _navIndex,
        onDestinationSelected: (i) => setState(() => _navIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.restaurant_outlined), selectedIcon: Icon(Icons.restaurant), label: 'Diet'),
          NavigationDestination(icon: Icon(Icons.fitness_center_outlined), selectedIcon: Icon(Icons.fitness_center), label: 'Workout'),
          NavigationDestination(icon: Icon(Icons.water_drop_outlined), selectedIcon: Icon(Icons.water_drop), label: 'Track'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Coach'),
        ],
      ),
    );
  }

  Widget _buildHome() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    final score = _healthScore?['total_score'] ?? 0;
    final xp = _gamification?['xp_points'] ?? 0;
    final streak = _gamification?['current_streak_days'] ?? 0;
    final level = _gamification?['level'] ?? 1;

    return RefreshIndicator(
      onRefresh: _loadData,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Namaste! 👋', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              IconButton(
                icon: const CircleAvatar(child: Icon(Icons.person)),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen())),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Health Score gradient hero card
          GradientCard(
            colors: AppColors.sleepGradient,
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Today\'s Health Score', style: TextStyle(color: Colors.white70, fontSize: 13)),
                      const SizedBox(height: 4),
                      Text('$score/100', style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text(_healthScore?['suggestion'] ?? '', style: const TextStyle(color: Colors.white70, fontSize: 12), maxLines: 2, overflow: TextOverflow.ellipsis),
                    ],
                  ),
                ),
                const Icon(Icons.favorite, color: Colors.white, size: 40),
              ],
            ),
          ),
          const SizedBox(height: 14),

          // XP / Streak / Level row
          Row(
            children: [
              Expanded(child: GradientCard(colors: AppColors.goldGradient, child: _miniStat('🔥', '$streak', 'Day Streak'))),
              const SizedBox(width: 12),
              Expanded(child: GradientCard(colors: [AppColors.primary, AppColors.teal], child: _miniStat('⭐', '$xp', 'XP • Lv $level'))),
            ],
          ),
          const SizedBox(height: 20),

          const Text('Quick Actions', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),

          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.3,
            children: [
              _actionCard('🥗', 'Diet Plan', AppColors.dietGradient, () => setState(() => _navIndex = 1)),
              _actionCard('💪', 'Workout', AppColors.workoutGradient, () => setState(() => _navIndex = 2)),
              _actionCard('💧', 'Water & Sleep', AppColors.waterGradient, () => setState(() => _navIndex = 3)),
              _actionCard('🤖', 'AI Coach', [AppColors.primary, AppColors.teal], () => setState(() => _navIndex = 4)),
            ],
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _miniStat(String emoji, String value, String label) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(emoji, style: const TextStyle(fontSize: 22)),
        const SizedBox(height: 6),
        Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)),
      ],
    );
  }

  Widget _actionCard(String emoji, String label, List<Color> colors, VoidCallback onTap) {
    return GradientCard(
      colors: colors,
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 30)),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
