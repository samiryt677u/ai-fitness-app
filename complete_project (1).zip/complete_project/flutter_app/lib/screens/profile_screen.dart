import 'package:flutter/material.dart';
import '../config/theme.dart';
import '../config/api_config.dart';
import '../services/api_service.dart';
import 'login_screen.dart';
import 'premium_screen.dart';
import 'exercise_library_screen.dart';
import 'food_photo_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Map<String, dynamic>? _user;
  Map<String, dynamic>? _profile;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final res = await ApiService.get(ApiConfig.getProfile);
    setState(() {
      _user = res['data']?['user'];
      _profile = res['data']?['profile'];
      _loading = false;
    });
  }

  Future<void> _logout() async {
    await ApiService.post(ApiConfig.logout, {});
    await ApiService.clearTokens();
    if (mounted) {
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginScreen()), (r) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Center(
                  child: Column(
                    children: [
                      const CircleAvatar(radius: 40, child: Icon(Icons.person, size: 40)),
                      const SizedBox(height: 12),
                      Text(_user?['name'] ?? '', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      Text(_user?['email'] ?? '', style: const TextStyle(color: AppColors.textMuted)),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                GradientCard(
                  colors: AppColors.goldGradient,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PremiumScreen())),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: const [
                      Text('👑 Upgrade to Premium', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      Icon(Icons.arrow_forward_ios, color: Colors.white, size: 16),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Card(
                  child: Column(
                    children: [
                      ListTile(
                        leading: const Icon(Icons.fitness_center_outlined, color: Color(0xFFF97316)),
                        title: const Text('Exercise Library'),
                        trailing: const Icon(Icons.arrow_forward_ios, size: 14),
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ExerciseLibraryScreen())),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: const Icon(Icons.camera_alt_outlined, color: AppColors.primary),
                        title: const Text('Food Photo Analysis'),
                        subtitle: const Text('Premium feature'),
                        trailing: const Icon(Icons.arrow_forward_ios, size: 14),
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FoodPhotoScreen())),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Profile Details', style: TextStyle(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 10),
                        _row('Goal', _profile?['goal'] ?? '-'),
                        _row('Height', '${_profile?['height_cm'] ?? '-'} cm'),
                        _row('Weight', '${_profile?['weight_kg'] ?? '-'} kg'),
                        _row('Fitness Level', _profile?['fitness_level'] ?? '-'),
                        _row('Diet Preference', _profile?['diet_preference'] ?? '-'),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                OutlinedButton(onPressed: _logout, child: const Text('Logout')),
              ],
            ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(label, style: const TextStyle(color: AppColors.textMuted)), Text(value)],
      ),
    );
  }
}
