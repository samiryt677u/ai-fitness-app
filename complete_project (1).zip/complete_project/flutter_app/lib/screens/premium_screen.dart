import 'package:flutter/material.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import '../config/theme.dart';
import '../config/api_config.dart';
import '../services/api_service.dart';

class PremiumScreen extends StatefulWidget {
  const PremiumScreen({super.key});
  @override
  State<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends State<PremiumScreen> {
  List<dynamic> _plans = [];
  bool _loading = true;
  late Razorpay _razorpay;
  Map? _pendingPlan;

  @override
  void initState() {
    super.initState();
    _loadPlans();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _onPaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _onPaymentError);
  }

  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }

  Future<void> _loadPlans() async {
    final res = await ApiService.get(ApiConfig.subscriptionPlans, auth: false);
    setState(() {
      _plans = res['data']?['plans'] ?? [];
      _loading = false;
    });
  }

  Future<void> _startCheckout(Map plan) async {
    _pendingPlan = plan;

    // Step 1: create a real Razorpay order via backend (amount verified server-side)
    final orderRes = await ApiService.post(ApiConfig.createOrder, {'plan_id': plan['id']});
    if (orderRes['success'] != true) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(orderRes['message'] ?? 'Could not start payment')));
      }
      return;
    }
    final orderData = orderRes['data'];

    // Step 2: open Razorpay checkout with the real order_id
    final options = {
      'key': orderData['razorpay_key'],
      'order_id': orderData['order_id'],
      'amount': orderData['amount'],
      'currency': orderData['currency'],
      'name': 'AI Fitness Coach',
      'description': orderData['plan_name'],
      'prefill': {'contact': '', 'email': ''},
      'theme': {'color': '#7C3AED'},
    };
    try {
      _razorpay.open(options);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open payment window')));
      }
    }
  }

  Future<void> _onPaymentSuccess(PaymentSuccessResponse response) async {
    final res = await ApiService.post(ApiConfig.verifyPayment, {
      'plan_id': _pendingPlan?['id'],
      'razorpay_order_id': response.orderId,
      'razorpay_payment_id': response.paymentId,
      'razorpay_signature': response.signature,
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res['success'] == true ? '🎉 Premium activated!' : (res['message'] ?? 'Verification failed'))),
      );
      if (res['success'] == true) Navigator.pop(context);
    }
  }

  void _onPaymentError(PaymentFailureResponse response) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Payment failed: ${response.message}')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Go Premium')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                GradientCard(
                  colors: AppColors.goldGradient,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text('👑 Unlock Premium', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                      SizedBox(height: 8),
                      Text('No ads • Unlimited AI chat • Food photo analysis • Full reports',
                          style: TextStyle(color: Colors.white70)),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                ..._plans.map((p) => Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(16),
                        title: Text(p['name'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        subtitle: Text('${p['duration_days']} days'),
                        trailing: ElevatedButton(
                          onPressed: () => _startCheckout(p),
                          child: Text('₹${p['price_inr']}'),
                        ),
                      ),
                    )),
              ],
            ),
    );
  }
}
