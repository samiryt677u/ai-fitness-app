import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../config/theme.dart';
import '../config/api_config.dart';

/// Premium-only feature: capture/pick a food photo and get AI calorie/macro analysis.
class FoodPhotoScreen extends StatefulWidget {
  const FoodPhotoScreen({super.key});
  @override
  State<FoodPhotoScreen> createState() => _FoodPhotoScreenState();
}

class _FoodPhotoScreenState extends State<FoodPhotoScreen> {
  File? _image;
  Map<String, dynamic>? _result;
  bool _loading = false;
  String? _error;

  Future<void> _pickImage(ImageSource source) async {
    final picked = await ImagePicker().pickImage(source: source, imageQuality: 80);
    if (picked == null) return;
    setState(() { _image = File(picked.path); _result = null; _error = null; });
    _analyze();
  }

  Future<void> _analyze() async {
    if (_image == null) return;
    setState(() { _loading = true; _error = null; });

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('access_token');

    final request = http.MultipartRequest('POST', Uri.parse(ApiConfig.foodPhotoAnalyze));
    request.headers['Authorization'] = 'Bearer $token';
    request.files.add(await http.MultipartFile.fromPath('image', _image!.path));

    try {
      final streamed = await request.send();
      final res = await http.Response.fromStream(streamed);
      final Map<String, dynamic> jsonData = jsonDecode(res.body);

      setState(() {
        _loading = false;
        if (jsonData['success'] == true) {
          _result = jsonData['data'];
        } else {
          _error = jsonData['message'] ?? 'Analysis failed. This is a Premium feature — please upgrade.';
        }
      });
    } catch (e) {
      setState(() { _loading = false; _error = 'Upload failed. Check your connection and try again.'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Food Photo Analysis')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            if (_image != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.file(_image!, height: 220, fit: BoxFit.cover, width: double.infinity),
              ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.camera_alt_outlined),
                    label: const Text('Camera'),
                    onPressed: () => _pickImage(ImageSource.camera),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.photo_library_outlined),
                    label: const Text('Gallery'),
                    onPressed: () => _pickImage(ImageSource.gallery),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            if (_loading) const CircularProgressIndicator(),
            if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center),
            if (_result != null)
              GradientCard(
                colors: AppColors.dietGradient,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_result!['food_name'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text('${_result!['calories']} kcal • Health Score: ${_result!['health_score']}/100', style: const TextStyle(color: Colors.white70)),
                    const SizedBox(height: 4),
                    Text('Protein: ${_result!['protein_g']}g • Carbs: ${_result!['carbs_g']}g • Fat: ${_result!['fat_g']}g', style: const TextStyle(color: Colors.white70)),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
