import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

/// Reusable AdMob banner — shown at the bottom of screens for FREE users only.
/// Wrap this widget with a premium check before rendering, e.g.:
///   if (!isPremium) const AdBannerWidget(adUnitId: 'ca-app-pub-xxx/banner'),
class AdBannerWidget extends StatefulWidget {
  final String adUnitId;
  const AdBannerWidget({super.key, required this.adUnitId});

  @override
  State<AdBannerWidget> createState() => _AdBannerWidgetState();
}

class _AdBannerWidgetState extends State<AdBannerWidget> {
  BannerAd? _bannerAd;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _loadAd();
  }

  void _loadAd() {
    _bannerAd = BannerAd(
      adUnitId: widget.adUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => _loaded = true),
        onAdFailedToLoad: (ad, error) => ad.dispose(),
      ),
    )..load();
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded || _bannerAd == null) return const SizedBox.shrink();
    return SizedBox(
      width: _bannerAd!.size.width.toDouble(),
      height: _bannerAd!.size.height.toDouble(),
      child: AdWidget(ad: _bannerAd!),
    );
  }
}

/// Interstitial ad helper — call InterstitialAdManager.show() after key actions
/// (e.g. after completing a workout) for FREE users.
class InterstitialAdManager {
  static InterstitialAd? _ad;

  static void load(String adUnitId) {
    InterstitialAd.load(
      adUnitId: adUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) => _ad = ad,
        onAdFailedToLoad: (_) => _ad = null,
      ),
    );
  }

  static void show(String adUnitId) {
    if (_ad != null) {
      _ad!.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (ad) { ad.dispose(); load(adUnitId); },
      );
      _ad!.show();
      _ad = null;
    } else {
      load(adUnitId);
    }
  }
}

/// Rewarded ad helper — e.g. "Watch ad to get +3 AI credits".
class RewardedAdManager {
  static RewardedAd? _ad;

  static void load(String adUnitId) {
    RewardedAd.load(
      adUnitId: adUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) => _ad = ad,
        onAdFailedToLoad: (_) => _ad = null,
      ),
    );
  }

  static void show(String adUnitId, void Function(int amount) onReward) {
    if (_ad != null) {
      _ad!.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (ad) { ad.dispose(); load(adUnitId); },
      );
      _ad!.show(onUserEarnedReward: (ad, reward) => onReward(reward.amount.toInt()));
      _ad = null;
    } else {
      load(adUnitId);
    }
  }
}
