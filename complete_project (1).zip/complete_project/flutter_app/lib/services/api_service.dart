import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../config/api_config.dart';

/// Central API service — handles auth token storage and all HTTP calls.
class ApiService {
  static Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('access_token');
  }

  static Future<void> saveTokens(String access, String refresh) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('access_token', access);
    await prefs.setString('refresh_token', refresh);
  }

  static Future<void> clearTokens() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('access_token');
    await prefs.remove('refresh_token');
  }

  static Future<Map<String, String>> _headers({bool auth = true}) async {
    final headers = {'Content-Type': 'application/json'};
    if (auth) {
      final token = await _getToken();
      if (token != null) headers['Authorization'] = 'Bearer $token';
    }
    return headers;
  }

  static Future<Map<String, dynamic>> post(String url, Map<String, dynamic> body, {bool auth = true}) async {
    final res = await http.post(Uri.parse(url), headers: await _headers(auth: auth), body: jsonEncode(body));
    return _parse(res);
  }

  static Future<Map<String, dynamic>> get(String url, {bool auth = true}) async {
    final res = await http.get(Uri.parse(url), headers: await _headers(auth: auth));
    return _parse(res);
  }

  static Map<String, dynamic> _parse(http.Response res) {
    try {
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      data['_statusCode'] = res.statusCode;
      return data;
    } catch (e) {
      return {'success': false, 'message': 'Server error. Please try again.', '_statusCode': res.statusCode};
    }
  }
}
