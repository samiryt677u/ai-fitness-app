class MealModel {
  final String mealType;
  final List<dynamic> foodItems;
  final int calories;
  final double proteinG;
  final double carbsG;
  final double fatG;
  final double estCostInr;

  MealModel({
    required this.mealType, required this.foodItems, required this.calories,
    required this.proteinG, required this.carbsG, required this.fatG, required this.estCostInr,
  });

  factory MealModel.fromJson(Map<String, dynamic> json) => MealModel(
        mealType: json['meal_type'] ?? '',
        foodItems: json['food_items'] is String ? [] : (json['food_items'] ?? []),
        calories: (json['calories'] ?? 0).toInt(),
        proteinG: double.tryParse('${json['protein_g']}') ?? 0,
        carbsG: double.tryParse('${json['carbs_g']}') ?? 0,
        fatG: double.tryParse('${json['fat_g']}') ?? 0,
        estCostInr: double.tryParse('${json['est_cost_inr']}') ?? 0,
      );
}

class DietPlanModel {
  final int totalCalories;
  final double totalProteinG;
  final double totalCarbsG;
  final double totalFatG;
  final List<MealModel> meals;

  DietPlanModel({
    required this.totalCalories, required this.totalProteinG,
    required this.totalCarbsG, required this.totalFatG, required this.meals,
  });

  factory DietPlanModel.fromJson(Map<String, dynamic> json) => DietPlanModel(
        totalCalories: (json['total_calories'] ?? 0).toInt(),
        totalProteinG: double.tryParse('${json['total_protein_g']}') ?? 0,
        totalCarbsG: double.tryParse('${json['total_carbs_g']}') ?? 0,
        totalFatG: double.tryParse('${json['total_fat_g']}') ?? 0,
        meals: (json['meals'] as List? ?? []).map((m) => MealModel.fromJson(m)).toList(),
      );
}
