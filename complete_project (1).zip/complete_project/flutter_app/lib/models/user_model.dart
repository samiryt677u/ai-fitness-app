class UserModel {
  final int id;
  final String name;
  final String email;
  final bool emailVerified;
  final String role;

  UserModel({required this.id, required this.name, required this.email, required this.emailVerified, required this.role});

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        id: json['user_id'] ?? json['id'],
        name: json['name'] ?? '',
        email: json['email'] ?? '',
        emailVerified: json['email_verified'] ?? false,
        role: json['role'] ?? 'user',
      );
}
