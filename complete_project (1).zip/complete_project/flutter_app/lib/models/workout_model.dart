class ExerciseModel {
  final int exerciseId;
  final String name;
  final int sets;
  final String reps;
  final int restSeconds;
  final String? videoUrl;

  ExerciseModel({
    required this.exerciseId, required this.name, required this.sets,
    required this.reps, required this.restSeconds, this.videoUrl,
  });

  factory ExerciseModel.fromJson(Map<String, dynamic> json) => ExerciseModel(
        exerciseId: json['exercise_id'] ?? 0,
        name: json['name'] ?? '',
        sets: (json['sets'] ?? 3).toInt(),
        reps: '${json['reps'] ?? '10-12'}',
        restSeconds: (json['rest_seconds'] ?? 60).toInt(),
        videoUrl: json['video_url'],
      );
}
