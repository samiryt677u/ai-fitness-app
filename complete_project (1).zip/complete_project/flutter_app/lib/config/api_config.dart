class ApiConfig {
  // Change to your deployed backend URL
  static const String baseUrl = 'https://api.yourdomain.com/api';

  static const String signup = '$baseUrl/auth/signup.php';
  static const String login = '$baseUrl/auth/login.php';
  static const String logout = '$baseUrl/auth/logout.php';
  static const String forgotPassword = '$baseUrl/auth/forgot_password.php';

  static const String getProfile = '$baseUrl/profile/get_profile.php';
  static const String updateProfile = '$baseUrl/profile/update_profile.php';

  static const String generateDiet = '$baseUrl/diet/generate_plan.php';
  static const String getDiet = '$baseUrl/diet/get_plan.php';

  static const String generateWorkout = '$baseUrl/workout/generate_plan.php';
  static const String startSession = '$baseUrl/workout/session_start.php';
  static const String completeSession = '$baseUrl/workout/session_complete.php';

  static const String water = '$baseUrl/tracker/water.php';
  static const String sleep = '$baseUrl/tracker/sleep.php';
  static const String healthScore = '$baseUrl/tracker/health_score.php';

  static const String gamificationStatus = '$baseUrl/gamification/status.php';

  static const String chatSend = '$baseUrl/chat/send_message.php';
  static const String chatHistory = '$baseUrl/chat/history.php';

  static const String creditsBalance = '$baseUrl/credits/balance.php';
  static const String subscriptionPlans = '$baseUrl/subscription/plans.php';
  static const String verifyPayment = '$baseUrl/subscription/verify_payment.php';
  static const String createOrder = '$baseUrl/subscription/create_order.php';
  static const String foodPhotoAnalyze = '$baseUrl/food_photo/analyze.php';
  static const String exercisesList = '$baseUrl/exercises/list.php';
}
