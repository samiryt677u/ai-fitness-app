import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Colorful SaaS-style design system for the AI Fitness App.
/// Module colors: Diet=green-teal, Workout=orange-red, Water=blue,
/// Sleep/Health=purple, Gamification=gold.
class AppColors {
  static const bgDark = Color(0xFF0D0D1F);
  static const primary = Color(0xFF7C3AED);
  static const teal = Color(0xFF06B6D4);

  static const dietGradient = [Color(0xFF10B981), Color(0xFF06B6D4)];
  static const workoutGradient = [Color(0xFFF97316), Color(0xFFEF4444)];
  static const waterGradient = [Color(0xFF3B82F6), Color(0xFF60A5FA)];
  static const sleepGradient = [Color(0xFF7C3AED), Color(0xFFA78BFA)];
  static const goldGradient = [Color(0xFFF59E0B), Color(0xFFFBBF24)];

  static const cardBg = Colors.white;
  static const textDark = Color(0xFF1F2937);
  static const textMuted = Color(0xFF6B7280);
}

class AppTheme {
  static ThemeData light() {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: const Color(0xFFF4F5FB),
      colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary),
      textTheme: GoogleFonts.interTextTheme(),
      cardTheme: CardThemeData(
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        color: AppColors.cardBg,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: GoogleFonts.inter(fontWeight: FontWeight.w600, fontSize: 16),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: AppColors.textDark,
      ),
    );
  }
}

/// Reusable gradient card widget used across dashboard modules.
class GradientCard extends StatelessWidget {
  final List<Color> colors;
  final Widget child;
  final VoidCallback? onTap;

  const GradientCard({super.key, required this.colors, required this.child, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: colors, begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: colors.last.withOpacity(0.35), blurRadius: 16, offset: const Offset(0, 8))],
        ),
        child: child,
      ),
    );
  }
}


class AppThemeDark {
  static ThemeData dark() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.bgDark,
      colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary, brightness: Brightness.dark),
      textTheme: GoogleFonts.interTextTheme(ThemeData(brightness: Brightness.dark).textTheme),
      cardTheme: CardThemeData(
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        color: const Color(0xFF1A1A3A),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: GoogleFonts.inter(fontWeight: FontWeight.w600, fontSize: 16),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF1A1A3A),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      appBarTheme: const AppBarTheme(backgroundColor: Colors.transparent, elevation: 0, foregroundColor: Colors.white),
    );
  }
}

/// Simple ChangeNotifier to toggle theme app-wide. Wrap MaterialApp with this
/// via Provider (see main.dart comments) to enable a Settings toggle.
class ThemeController extends ChangeNotifier {
  bool _isDark = false;
  bool get isDark => _isDark;
  ThemeData get theme => _isDark ? AppThemeDark.dark() : AppTheme.light();

  void toggle() {
    _isDark = !_isDark;
    notifyListeners();
  }
}
