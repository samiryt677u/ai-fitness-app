# Android Setup Notes

## 1. AdMob App ID (required in AndroidManifest.xml)

Add inside `<application>` tag in `android/app/src/main/AndroidManifest.xml`:

```xml
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY"/>
```

Get this ID from your AdMob console (different from ad unit IDs used in the app).

## 2. Permissions

Add to AndroidManifest.xml (needed for image_picker camera access):

```xml
<uses-permission android:name="android.permission.CAMERA"/>
<uses-permission android:name="android.permission.INTERNET"/>
```

## 3. minSdkVersion

Set `minSdkVersion 21` (or higher) in `android/app/build.gradle` — required by
google_mobile_ads and razorpay_flutter.

## 4. Package name for Play Store

Update `applicationId` in `android/app/build.gradle` to your unique package name,
e.g. `com.yourcompany.aifitnessapp`.

## 5. App icon + splash

Use `flutter_launcher_icons` and `flutter_native_splash` packages (add to
pubspec.yaml dev_dependencies) to generate branded icons matching your gradient
purple-teal design system.
