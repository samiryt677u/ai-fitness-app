<?php
require_once __DIR__ . '/includes/auth.php';
$admin = admin_login_check();
$db = DB::conn();

$featureUsage = $db->query(
    "SELECT feature_key, COUNT(*) as cnt, SUM(used_ai) as ai_calls
     FROM feature_usage_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
     GROUP BY feature_key ORDER BY cnt DESC"
)->fetchAll();

$dailyActive = $db->query(
    "SELECT DATE(created_at) as d, COUNT(DISTINCT user_id) as cnt
     FROM feature_usage_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 14 DAY)
     GROUP BY DATE(created_at) ORDER BY d"
)->fetchAll();

$pageTitle = 'Analytics';
include __DIR__ . '/includes/header.php';
?>
<h3 class="mb-4">Analytics (Last 30 Days)</h3>

<div class="card stat-card p-3 mb-4">
  <h6>Feature Usage</h6>
  <table class="table">
    <thead><tr><th>Feature</th><th>Total Uses</th><th>AI Calls</th></tr></thead>
    <tbody>
    <?php foreach ($featureUsage as $f): ?>
      <tr><td class="text-capitalize"><?= str_replace('_',' ',$f['feature_key']) ?></td><td><?= $f['cnt'] ?></td><td><?= $f['ai_calls'] ?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div class="card stat-card p-3">
  <h6>Daily Active Users (Last 14 Days)</h6>
  <table class="table">
    <thead><tr><th>Date</th><th>Active Users</th></tr></thead>
    <tbody>
    <?php foreach ($dailyActive as $d): ?>
      <tr><td><?= date('d M', strtotime($d['d'])) ?></td><td><?= $d['cnt'] ?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
