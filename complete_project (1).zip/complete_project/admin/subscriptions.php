<?php
require_once __DIR__ . '/includes/auth.php';
$admin = admin_login_check();
$db = DB::conn();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $days = (int) $_POST['duration_days'];
    $price = (float) $_POST['price_inr'];
    if ($name && $days && $price) {
        $db->prepare("INSERT INTO subscription_plans (name, duration_days, price_inr, features) VALUES (?, ?, ?, '[]')")
           ->execute([$name, $days, $price]);
        log_admin_action($admin['id'], 'create_plan', 'subscription_plan', (int) $db->lastInsertId());
    }
    header('Location: subscriptions.php');
    exit;
}

$plans = $db->query("SELECT * FROM subscription_plans ORDER BY sort_order")->fetchAll();
$pageTitle = 'Subscriptions';
include __DIR__ . '/includes/header.php';
?>
<h3 class="mb-4">Subscription Plans</h3>

<div class="card stat-card p-3 mb-4">
  <h6>Add New Plan</h6>
  <form method="POST" class="row g-2">
    <div class="col-md-4"><input name="name" class="form-control" placeholder="Plan name" required></div>
    <div class="col-md-3"><input name="duration_days" type="number" class="form-control" placeholder="Duration (days)" required></div>
    <div class="col-md-3"><input name="price_inr" type="number" step="0.01" class="form-control" placeholder="Price (INR)" required></div>
    <div class="col-md-2"><button class="btn btn-primary w-100">Add Plan</button></div>
  </form>
</div>

<div class="card stat-card p-3">
  <table class="table">
    <thead><tr><th>Name</th><th>Duration</th><th>Price</th><th>Status</th></tr></thead>
    <tbody>
    <?php foreach ($plans as $p): ?>
      <tr>
        <td><?= htmlspecialchars($p['name']) ?></td>
        <td><?= $p['duration_days'] ?> days</td>
        <td>₹<?= number_format($p['price_inr'], 2) ?></td>
        <td><span class="badge <?= $p['is_active'] ? 'bg-success' : 'bg-secondary' ?>"><?= $p['is_active'] ? 'Active' : 'Inactive' ?></span></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
