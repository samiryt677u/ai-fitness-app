# Admin Panel Setup

1. Upload `admin/` folder alongside `backend/` on your server (same parent directory),
   e.g.: `public_html/backend/` and `public_html/admin/` — admin panel reads DB config
   directly from `../backend/config/db.php`.
2. Create your first admin user manually via phpMyAdmin:

```sql
INSERT INTO users (name, email, password_hash, role, status, email_verified)
VALUES ('Admin', 'admin@yourdomain.com', '$2y$10$REPLACE_WITH_BCRYPT_HASH', 'admin', 'active', 1);
```

   Generate the bcrypt hash using PHP: `password_hash('yourpassword', PASSWORD_BCRYPT)`
   or any online bcrypt generator.

3. Visit `https://yourdomain.com/admin/login.php` and log in.

## Pages
- **Dashboard** — total users, active today, premium count, revenue
- **Users** — search, block/unblock, manually grant premium
- **Subscriptions** — create/view plans
- **Transactions** — payment history
- **Ad Control** — edit AdMob unit IDs, enable/disable per ad type
- **AI Control Panel** — edit Gemini system prompts, tokens, temperature live
- **Analytics** — feature usage + daily active users (last 30/14 days)
