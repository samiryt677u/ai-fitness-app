<?php
require_once __DIR__ . '/includes/auth.php';
$admin = admin_login_check();
$db = DB::conn();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST['ad'] as $id => $vals) {
        $db->prepare("UPDATE ad_settings SET ad_unit_id = ?, is_enabled = ? WHERE id = ?")
           ->execute([$vals['unit_id'], isset($vals['enabled']) ? 1 : 0, $id]);
    }
    log_admin_action($admin['id'], 'update_ad_settings');
    header('Location: ad_settings.php');
    exit;
}

$ads = $db->query("SELECT * FROM ad_settings ORDER BY ad_type")->fetchAll();
$pageTitle = 'Ad Control';
include __DIR__ . '/includes/header.php';
?>
<h3 class="mb-4">AdMob Control</h3>
<div class="card stat-card p-3">
  <form method="POST">
    <table class="table align-middle">
      <thead><tr><th>Type</th><th>Platform</th><th>Ad Unit ID</th><th>Enabled</th></tr></thead>
      <tbody>
      <?php foreach ($ads as $ad): ?>
        <tr>
          <td class="text-capitalize"><?= $ad['ad_type'] ?></td>
          <td class="text-capitalize"><?= $ad['platform'] ?></td>
          <td><input type="text" class="form-control" name="ad[<?= $ad['id'] ?>][unit_id]" value="<?= htmlspecialchars($ad['ad_unit_id']) ?>"></td>
          <td><input type="checkbox" class="form-check-input" name="ad[<?= $ad['id'] ?>][enabled]" <?= $ad['is_enabled'] ? 'checked' : '' ?>></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <button class="btn btn-primary">Save Changes</button>
  </form>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
