<?php
require_once __DIR__ . '/includes/auth.php';
$admin = admin_login_check();
$db = DB::conn();

$txns = $db->query(
    "SELECT t.*, u.name, u.email FROM transactions t JOIN users u ON u.id = t.user_id ORDER BY t.created_at DESC LIMIT 100"
)->fetchAll();

$pageTitle = 'Transactions';
include __DIR__ . '/includes/header.php';
?>
<h3 class="mb-4">Transactions</h3>
<div class="card stat-card p-3">
  <table class="table table-hover">
    <thead><tr><th>User</th><th>Order ID</th><th>Amount</th><th>Status</th><th>Gateway</th><th>Date</th></tr></thead>
    <tbody>
    <?php foreach ($txns as $t): ?>
      <tr>
        <td><?= htmlspecialchars($t['name']) ?><br><small class="text-muted"><?= htmlspecialchars($t['email']) ?></small></td>
        <td><?= htmlspecialchars($t['order_id']) ?></td>
        <td>₹<?= number_format($t['amount_inr'], 2) ?></td>
        <td><span class="badge <?= $t['status']==='success' ? 'bg-success' : ($t['status']==='failed' ? 'bg-danger' : 'bg-warning') ?>"><?= $t['status'] ?></span></td>
        <td><?= htmlspecialchars($t['payment_gateway']) ?></td>
        <td><?= date('d M Y, h:i A', strtotime($t['created_at'])) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
