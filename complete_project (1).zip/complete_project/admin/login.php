<?php
session_start();
require_once __DIR__ . '/../backend/config/db.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = DB::conn()->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin'");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password_hash'])) {
        $_SESSION['admin_id'] = $admin['id'];
        header('Location: dashboard.php');
        exit;
    }
    $error = 'Invalid credentials or not an admin account';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login — FitAI</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" rel="stylesheet">
<style>
  body { background: linear-gradient(135deg, #0d0d1f, #1a1a3a); height: 100vh; display: flex; align-items: center; justify-content: center; }
  .login-card { border-radius: 20px; border: none; box-shadow: 0 10px 40px rgba(0,0,0,0.3); width: 380px; }
  .btn-gradient { background: linear-gradient(90deg, #7c3aed, #06b6d4); border: none; color: #fff; }
</style>
</head>
<body>
<div class="card login-card p-4">
  <h3 class="text-center mb-1">🏋️ FitAI Admin</h3>
  <p class="text-center text-muted mb-4">Sign in to manage your app</p>
  <?php if ($error): ?><div class="alert alert-danger py-2"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <form method="POST">
    <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" required></div>
    <div class="mb-3"><label class="form-label">Password</label><input type="password" name="password" class="form-control" required></div>
    <button type="submit" class="btn btn-gradient w-100 py-2">Login</button>
  </form>
</div>
</body>
</html>
