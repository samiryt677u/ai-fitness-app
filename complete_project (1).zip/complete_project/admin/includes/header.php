<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?? 'Admin Panel' ?> — AI Fitness Admin</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<style>
  :root {
    --primary: #7c3aed;
    --teal: #06b6d4;
    --bg: #0d0d1f;
  }
  body { background: #f4f5fb; font-family: 'Segoe UI', system-ui, sans-serif; }
  .sidebar {
    background: linear-gradient(180deg, #0d0d1f 0%, #1a1a3a 100%);
    min-height: 100vh; color: #fff; width: 240px; position: fixed;
  }
  .sidebar a { color: #cfcfe8; text-decoration: none; display: block; padding: 12px 20px; border-radius: 8px; margin: 4px 10px; }
  .sidebar a:hover, .sidebar a.active { background: linear-gradient(90deg, var(--primary), var(--teal)); color: #fff; }
  .main-content { margin-left: 260px; padding: 30px; }
  .stat-card { border-radius: 16px; border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.06); }
  .stat-card .icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; color: #fff; }
  .badge-premium { background: linear-gradient(90deg, #f59e0b, #f97316); }
</style>
</head>
<body>
<div class="sidebar p-3">
  <h4 class="text-white mb-4 px-2"><i class="fa-solid fa-dumbbell"></i> FitAI Admin</h4>
  <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : '' ?>"><i class="fa-solid fa-chart-line me-2"></i> Dashboard</a>
  <a href="users.php" class="<?= basename($_SERVER['PHP_SELF']) === 'users.php' ? 'active' : '' ?>"><i class="fa-solid fa-users me-2"></i> Users</a>
  <a href="subscriptions.php" class="<?= basename($_SERVER['PHP_SELF']) === 'subscriptions.php' ? 'active' : '' ?>"><i class="fa-solid fa-crown me-2"></i> Subscriptions</a>
  <a href="transactions.php" class="<?= basename($_SERVER['PHP_SELF']) === 'transactions.php' ? 'active' : '' ?>"><i class="fa-solid fa-receipt me-2"></i> Transactions</a>
  <a href="ad_settings.php" class="<?= basename($_SERVER['PHP_SELF']) === 'ad_settings.php' ? 'active' : '' ?>"><i class="fa-solid fa-rectangle-ad me-2"></i> Ad Control</a>
  <a href="ai_prompts.php" class="<?= basename($_SERVER['PHP_SELF']) === 'ai_prompts.php' ? 'active' : '' ?>"><i class="fa-solid fa-robot me-2"></i> AI Control</a>
  <a href="analytics.php" class="<?= basename($_SERVER['PHP_SELF']) === 'analytics.php' ? 'active' : '' ?>"><i class="fa-solid fa-chart-pie me-2"></i> Analytics</a>
  <hr class="text-secondary">
  <a href="logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i> Logout</a>
</div>
<div class="main-content">
