<?php
session_start();
require_once __DIR__ . '/../../backend/config/db.php';

function admin_login_check(): array {
    if (empty($_SESSION['admin_id'])) {
        header('Location: login.php');
        exit;
    }
    $stmt = DB::conn()->prepare("SELECT * FROM users WHERE id = ? AND role = 'admin' AND status = 'active'");
    $stmt->execute([$_SESSION['admin_id']]);
    $admin = $stmt->fetch();
    if (!$admin) {
        session_destroy();
        header('Location: login.php');
        exit;
    }
    return $admin;
}

function log_admin_action(int $adminId, string $action, ?string $targetType = null, ?int $targetId = null, ?string $details = null): void {
    DB::conn()->prepare(
        "INSERT INTO admin_activity_log (admin_id, action, target_type, target_id, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)"
    )->execute([$adminId, $action, $targetType, $targetId, $details, $_SERVER['REMOTE_ADDR'] ?? null]);
}
