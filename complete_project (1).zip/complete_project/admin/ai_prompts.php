<?php
require_once __DIR__ . '/includes/auth.php';
$admin = admin_login_check();
$db = DB::conn();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db->prepare("UPDATE ai_prompts SET prompt_text = ?, max_tokens = ?, temperature = ?, is_active = ? WHERE id = ?")
       ->execute([
           $_POST['prompt_text'], (int) $_POST['max_tokens'], (float) $_POST['temperature'],
           isset($_POST['is_active']) ? 1 : 0, (int) $_POST['id'],
       ]);
    log_admin_action($admin['id'], 'update_ai_prompt', 'ai_prompt', (int) $_POST['id']);
    header('Location: ai_prompts.php');
    exit;
}

$prompts = $db->query("SELECT * FROM ai_prompts")->fetchAll();
$pageTitle = 'AI Control Panel';
include __DIR__ . '/includes/header.php';
?>
<h3 class="mb-4">AI Control Panel</h3>
<?php foreach ($prompts as $p): ?>
<div class="card stat-card p-3 mb-3">
  <form method="POST">
    <input type="hidden" name="id" value="<?= $p['id'] ?>">
    <h6 class="text-primary"><?= htmlspecialchars($p['prompt_key']) ?> <small class="text-muted">(<?= $p['model_name'] ?>)</small></h6>
    <textarea name="prompt_text" class="form-control mb-2" rows="4"><?= htmlspecialchars($p['prompt_text']) ?></textarea>
    <div class="row g-2 mb-2">
      <div class="col-md-3"><label class="form-label small">Max Tokens</label><input type="number" name="max_tokens" class="form-control" value="<?= $p['max_tokens'] ?>"></div>
      <div class="col-md-3"><label class="form-label small">Temperature</label><input type="number" step="0.1" name="temperature" class="form-control" value="<?= $p['temperature'] ?>"></div>
      <div class="col-md-3 d-flex align-items-end"><div class="form-check"><input type="checkbox" name="is_active" class="form-check-input" <?= $p['is_active'] ? 'checked' : '' ?>><label class="form-check-label">Active</label></div></div>
    </div>
    <button class="btn btn-sm btn-primary">Save</button>
  </form>
</div>
<?php endforeach; ?>
<?php include __DIR__ . '/includes/footer.php'; ?>
