<?php
require_once __DIR__ . '/includes/auth.php';
$admin = admin_login_check();
$db = DB::conn();

$totalUsers = $db->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn();
$activeToday = $db->query("SELECT COUNT(DISTINCT user_id) FROM feature_usage_logs WHERE DATE(created_at) = CURDATE()")->fetchColumn();
$premiumUsers = $db->query("SELECT COUNT(*) FROM user_subscriptions WHERE status = 'active' AND expires_at > NOW()")->fetchColumn();
$totalRevenue = $db->query("SELECT COALESCE(SUM(amount_inr),0) FROM transactions WHERE status = 'success'")->fetchColumn();
$monthRevenue = $db->query("SELECT COALESCE(SUM(amount_inr),0) FROM transactions WHERE status = 'success' AND MONTH(created_at) = MONTH(CURDATE())")->fetchColumn();

$recentUsers = $db->query("SELECT id, name, email, created_at FROM users WHERE role = 'user' ORDER BY created_at DESC LIMIT 5")->fetchAll();

$pageTitle = 'Dashboard';
include __DIR__ . '/includes/header.php';
?>
<h3 class="mb-4">Dashboard</h3>
<div class="row g-3 mb-4">
  <div class="col-md-3">
    <div class="card stat-card p-3 d-flex flex-row align-items-center gap-3">
      <div class="icon" style="background:linear-gradient(135deg,#7c3aed,#a78bfa)"><i class="fa-solid fa-users"></i></div>
      <div><div class="text-muted small">Total Users</div><h4 class="mb-0"><?= number_format($totalUsers) ?></h4></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card stat-card p-3 d-flex flex-row align-items-center gap-3">
      <div class="icon" style="background:linear-gradient(135deg,#06b6d4,#22d3ee)"><i class="fa-solid fa-bolt"></i></div>
      <div><div class="text-muted small">Active Today</div><h4 class="mb-0"><?= number_format($activeToday) ?></h4></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card stat-card p-3 d-flex flex-row align-items-center gap-3">
      <div class="icon" style="background:linear-gradient(135deg,#f59e0b,#f97316)"><i class="fa-solid fa-crown"></i></div>
      <div><div class="text-muted small">Premium Users</div><h4 class="mb-0"><?= number_format($premiumUsers) ?></h4></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card stat-card p-3 d-flex flex-row align-items-center gap-3">
      <div class="icon" style="background:linear-gradient(135deg,#22c55e,#4ade80)"><i class="fa-solid fa-indian-rupee-sign"></i></div>
      <div><div class="text-muted small">Total Revenue</div><h4 class="mb-0">₹<?= number_format($totalRevenue) ?></h4></div>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-md-6">
    <div class="card stat-card p-3">
      <h6>This Month Revenue</h6>
      <h3 class="text-success">₹<?= number_format($monthRevenue) ?></h3>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card stat-card p-3">
      <h6 class="mb-3">Recent Signups</h6>
      <table class="table table-sm">
        <thead><tr><th>Name</th><th>Email</th><th>Joined</th></tr></thead>
        <tbody>
        <?php foreach ($recentUsers as $u): ?>
          <tr><td><?= htmlspecialchars($u['name']) ?></td><td><?= htmlspecialchars($u['email']) ?></td><td><?= date('d M Y', strtotime($u['created_at'])) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
