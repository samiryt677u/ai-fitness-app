<?php
require_once __DIR__ . '/includes/auth.php';
$admin = admin_login_check();
$db = DB::conn();

$search = trim($_GET['search'] ?? '');
$sql = "SELECT u.*,
        (SELECT COUNT(*) FROM user_subscriptions s WHERE s.user_id = u.id AND s.status='active' AND s.expires_at > NOW()) as is_premium
        FROM users u WHERE u.role = 'user'";
$params = [];
if ($search) {
    $sql .= " AND (u.name LIKE ? OR u.email LIKE ?)";
    $params = ["%$search%", "%$search%"];
}
$sql .= " ORDER BY u.created_at DESC LIMIT 100";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

$pageTitle = 'Users';
include __DIR__ . '/includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-4">
  <h3>User Management</h3>
  <form class="d-flex gap-2" method="GET">
    <input type="text" name="search" class="form-control" placeholder="Search name/email" value="<?= htmlspecialchars($search) ?>">
    <button class="btn btn-primary">Search</button>
  </form>
</div>

<div class="card stat-card p-3">
  <table class="table table-hover align-middle">
    <thead><tr><th>Name</th><th>Email</th><th>Status</th><th>Plan</th><th>Joined</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ($users as $u): ?>
      <tr>
        <td><?= htmlspecialchars($u['name']) ?></td>
        <td><?= htmlspecialchars($u['email']) ?></td>
        <td><span class="badge <?= $u['status']==='active' ? 'bg-success' : 'bg-danger' ?>"><?= $u['status'] ?></span></td>
        <td><?= $u['is_premium'] ? '<span class="badge badge-premium">Premium</span>' : '<span class="badge bg-secondary">Free</span>' ?></td>
        <td><?= date('d M Y', strtotime($u['created_at'])) ?></td>
        <td>
          <form method="POST" action="actions/user_action.php" class="d-inline">
            <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
            <input type="hidden" name="action" value="<?= $u['status']==='active' ? 'block' : 'unblock' ?>">
            <button class="btn btn-sm <?= $u['status']==='active' ? 'btn-outline-danger' : 'btn-outline-success' ?>">
              <?= $u['status']==='active' ? 'Block' : 'Unblock' ?>
            </button>
          </form>
          <form method="POST" action="actions/user_action.php" class="d-inline">
            <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
            <input type="hidden" name="action" value="assign_premium">
            <button class="btn btn-sm btn-outline-warning">Grant Premium (30d)</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
