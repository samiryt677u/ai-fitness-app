<?php
require_once __DIR__ . '/../includes/auth.php';
$admin = admin_login_check();
$db = DB::conn();

$userId = (int) ($_POST['user_id'] ?? 0);
$action = $_POST['action'] ?? '';

if (!$userId || !$action) { header('Location: ../users.php'); exit; }

switch ($action) {
    case 'block':
        $db->prepare("UPDATE users SET status = 'blocked' WHERE id = ?")->execute([$userId]);
        log_admin_action($admin['id'], 'block_user', 'user', $userId);
        break;

    case 'unblock':
        $db->prepare("UPDATE users SET status = 'active' WHERE id = ?")->execute([$userId]);
        log_admin_action($admin['id'], 'unblock_user', 'user', $userId);
        break;

    case 'assign_premium':
        $plan = $db->query("SELECT id FROM subscription_plans WHERE is_active=1 ORDER BY sort_order LIMIT 1")->fetch();
        if ($plan) {
            $db->prepare(
                "INSERT INTO user_subscriptions (user_id, plan_id, started_at, expires_at, status, assigned_by)
                 VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY), 'active', 'admin')"
            )->execute([$userId, $plan['id']]);
            log_admin_action($admin['id'], 'assign_premium_manual', 'user', $userId, '30 days granted');
        }
        break;
}

header('Location: ../users.php');
exit;
