# AI Smart Fitness & Diet App — Backend (PHP + MySQL)

## Setup on cPanel

1. Upload the `backend/` folder to your subdomain (e.g. `api.yourdomain.com`).
2. Import `database/schema.sql` via phpMyAdmin.
3. Edit `config/config.php`:
   - DB_HOST, DB_NAME, DB_USER, DB_PASS (from cPanel MySQL)
   - JWT_SECRET (generate a long random string)
   - SMTP_* (from your cPanel email account, same pattern as unitopper.in)
   - GEMINI_API_KEY (from Google AI Studio — free tier)
   - RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET
4. Ensure PHP 8+ with PDO MySQL extension enabled (default on cPanel).
5. Test: POST to `https://api.yourdomain.com/api/auth/signup.php`

## Architecture

- Rule-based engines (`includes/RuleBasedDietEngine.php`, `RuleBasedWorkoutEngine.php`)
  handle diet & workout generation with ZERO AI cost — used for all users.
- `includes/GeminiClient.php` is used ONLY for AI Chat Coach and Food Photo Analysis
  (premium feature), keeping AI cost minimal as discussed.
- `includes/CreditManager.php` gives free users limited daily AI credits (default 5/day,
  configurable via FREE_DAILY_CREDITS). Premium users bypass credit checks.
- JWT auth implemented manually (helpers/jwt.php) — no composer dependency needed,
  works directly on shared cPanel hosting.

## API Endpoints

### Auth (public)
- POST /api/auth/signup.php
- POST /api/auth/login.php
- POST /api/auth/logout.php (auth required)
- POST /api/auth/forgot_password.php
- POST /api/auth/reset_password.php
- POST /api/auth/verify_email.php

### Profile (auth required)
- GET  /api/profile/get_profile.php
- PUT  /api/profile/update_profile.php

### Diet (auth required)
- POST /api/diet/generate_plan.php
- GET  /api/diet/get_plan.php?date=YYYY-MM-DD

### Workout (auth required)
- POST /api/workout/generate_plan.php
- POST /api/workout/session_start.php
- POST /api/workout/session_complete.php

### Trackers (auth required)
- GET/POST /api/tracker/water.php
- GET/POST /api/tracker/sleep.php
- GET  /api/tracker/health_score.php

### Gamification (auth required)
- GET /api/gamification/status.php

### AI Chat (auth required, credit/premium gated)
- POST /api/chat/send_message.php
- GET  /api/chat/history.php
- GET  /api/chat/history.php?conversation_id=X

### Credits (auth required)
- GET /api/credits/balance.php

### Subscription
- GET  /api/subscription/plans.php (public)
- POST /api/subscription/verify_payment.php (auth required, Razorpay webhook style)

## Auth Header

All protected endpoints require:
```
Authorization: Bearer <access_token>
```

## Notes

- Diet/Workout plans are cached per day (one generation per user per day) to avoid
  redundant DB writes and keep the app fast.
- Food Photo Analysis endpoint is intentionally NOT included in this phase — it needs
  file upload handling + Gemini vision call, to be added in the next phase along with
  the admin panel and Flutter app.
- Admin panel (web) and Flutter app are separate deliverables — next in the build queue.
