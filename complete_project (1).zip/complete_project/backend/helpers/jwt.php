<?php
require_once __DIR__ . '/../config/config.php';

// Lightweight manual HS256 JWT implementation (no composer dependency needed on cPanel)
class JWT {

    public static function encode(array $payload, int $ttlSeconds): string {
        $header = self::b64(json_encode(['typ' => 'JWT', 'alg' => 'HS256']));
        $payload['iat'] = time();
        $payload['exp'] = time() + $ttlSeconds;
        $payloadEnc = self::b64(json_encode($payload));
        $signature = self::sign("$header.$payloadEnc");
        return "$header.$payloadEnc.$signature";
    }

    public static function decode(string $token): ?array {
        $parts = explode('.', $token);
        if (count($parts) !== 3) return null;
        [$header, $payload, $signature] = $parts;

        $expected = self::sign("$header.$payload");
        if (!hash_equals($expected, $signature)) return null;

        $data = json_decode(self::unb64($payload), true);
        if (!$data || (isset($data['exp']) && $data['exp'] < time())) return null;

        return $data;
    }

    private static function sign(string $data): string {
        return self::b64(hash_hmac('sha256', $data, JWT_SECRET, true));
    }

    private static function b64(string $data): string {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private static function unb64(string $data): string {
        $pad = strlen($data) % 4;
        if ($pad) $data .= str_repeat('=', 4 - $pad);
        return base64_decode(strtr($data, '-_', '+/'));
    }

    public static function getBearerToken(): ?string {
        $headers = function_exists('getallheaders') ? getallheaders() : [];
        $auth = $headers['Authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (preg_match('/Bearer\s(\S+)/', $auth, $m)) return $m[1];
        return null;
    }
}
