<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

function success($data = [], string $message = 'OK', int $code = 200): void {
    http_response_code($code);
    echo json_encode(['success' => true, 'message' => $message, 'data' => $data]);
    exit;
}

function fail(string $message = 'Error', int $code = 400, $errors = null): void {
    http_response_code($code);
    $resp = ['success' => false, 'message' => $message];
    if ($errors !== null) $resp['errors'] = $errors;
    echo json_encode($resp);
    exit;
}

function get_json_input(): array {
    $input = json_decode(file_get_contents('php://input'), true);
    return is_array($input) ? $input : [];
}

function require_fields(array $input, array $fields): void {
    $missing = [];
    foreach ($fields as $f) {
        if (!isset($input[$f]) || $input[$f] === '') $missing[] = $f;
    }
    if (!empty($missing)) {
        fail('Missing required fields: ' . implode(', ', $missing), 422);
    }
}
