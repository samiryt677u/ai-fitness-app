-- ============================================================
-- AI SMART FITNESS & DIET APP — COMPLETE DATABASE SCHEMA
-- Engine: MySQL 8.0+ | Charset: utf8mb4
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;

CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20) DEFAULT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email_verified TINYINT(1) NOT NULL DEFAULT 0,
    email_verify_token VARCHAR(255) DEFAULT NULL,
    password_reset_token VARCHAR(255) DEFAULT NULL,
    password_reset_expires DATETIME DEFAULT NULL,
    status ENUM('active','blocked','deleted') NOT NULL DEFAULT 'active',
    role ENUM('user','admin') NOT NULL DEFAULT 'user',
    profile_photo VARCHAR(255) DEFAULT NULL,
    last_login_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_email (email),
    INDEX idx_users_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE user_sessions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    refresh_token VARCHAR(500) NOT NULL,
    device_info VARCHAR(255) DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sessions_user (user_id),
    INDEX idx_sessions_token (refresh_token(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE user_profiles (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL UNIQUE,
    age TINYINT UNSIGNED DEFAULT NULL,
    gender ENUM('male','female','other') DEFAULT NULL,
    height_cm DECIMAL(5,2) DEFAULT NULL,
    weight_kg DECIMAL(5,2) DEFAULT NULL,
    target_weight_kg DECIMAL(5,2) DEFAULT NULL,
    goal ENUM('weight_loss','muscle_gain','maintain_fitness') DEFAULT NULL,
    activity_level ENUM('sedentary','light','moderate','active','very_active') NOT NULL DEFAULT 'moderate',
    diet_preference ENUM('veg','non_veg','egg_veg','vegan') NOT NULL DEFAULT 'veg',
    fitness_level ENUM('beginner','intermediate','advanced') NOT NULL DEFAULT 'beginner',
    workout_location ENUM('home','gym','both') NOT NULL DEFAULT 'home',
    budget_preference ENUM('low','medium','high') NOT NULL DEFAULT 'medium',
    bmr DECIMAL(7,2) DEFAULT NULL,
    tdee DECIMAL(7,2) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE diet_plans (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    plan_date DATE NOT NULL,
    source ENUM('rule_based','ai') NOT NULL DEFAULT 'rule_based',
    total_calories INT UNSIGNED DEFAULT NULL,
    total_protein_g DECIMAL(6,2) DEFAULT NULL,
    total_carbs_g DECIMAL(6,2) DEFAULT NULL,
    total_fat_g DECIMAL(6,2) DEFAULT NULL,
    cache_key VARCHAR(150) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_diet_user_date (user_id, plan_date),
    INDEX idx_diet_cache_key (cache_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE diet_plan_meals (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    diet_plan_id BIGINT UNSIGNED NOT NULL,
    meal_type ENUM('breakfast','lunch','dinner','snack') NOT NULL,
    food_items TEXT NOT NULL,
    calories INT UNSIGNED DEFAULT NULL,
    protein_g DECIMAL(6,2) DEFAULT NULL,
    carbs_g DECIMAL(6,2) DEFAULT NULL,
    fat_g DECIMAL(6,2) DEFAULT NULL,
    est_cost_inr DECIMAL(6,2) DEFAULT NULL,
    FOREIGN KEY (diet_plan_id) REFERENCES diet_plans(id) ON DELETE CASCADE,
    INDEX idx_meal_plan (diet_plan_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE food_items (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    category VARCHAR(80) DEFAULT NULL,
    is_veg TINYINT(1) NOT NULL DEFAULT 1,
    calories_per_100g DECIMAL(6,2) NOT NULL,
    protein_per_100g DECIMAL(6,2) DEFAULT NULL,
    carbs_per_100g DECIMAL(6,2) DEFAULT NULL,
    fat_per_100g DECIMAL(6,2) DEFAULT NULL,
    region VARCHAR(50) DEFAULT 'indian',
    avg_cost_inr_per_100g DECIMAL(6,2) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_food_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE food_photo_analysis (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    detected_food VARCHAR(255) DEFAULT NULL,
    calories INT UNSIGNED DEFAULT NULL,
    protein_g DECIMAL(6,2) DEFAULT NULL,
    carbs_g DECIMAL(6,2) DEFAULT NULL,
    fat_g DECIMAL(6,2) DEFAULT NULL,
    health_score TINYINT UNSIGNED DEFAULT NULL,
    ai_raw_response TEXT DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_photo_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE exercises (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    category ENUM('beginner','intermediate','advanced') NOT NULL,
    muscle_group VARCHAR(80) DEFAULT NULL,
    equipment ENUM('none','home','gym') NOT NULL DEFAULT 'none',
    goal_tag ENUM('weight_loss','muscle_gain','maintain_fitness','all') NOT NULL DEFAULT 'all',
    default_sets TINYINT UNSIGNED DEFAULT 3,
    default_reps VARCHAR(20) DEFAULT '10-12',
    rest_seconds SMALLINT UNSIGNED DEFAULT 60,
    calories_burned_per_min DECIMAL(5,2) DEFAULT NULL,
    video_url VARCHAR(255) DEFAULT NULL,
    instructions TEXT DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ex_category (category),
    INDEX idx_ex_goal (goal_tag)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE workout_plans (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    plan_date DATE NOT NULL,
    source ENUM('rule_based','ai') NOT NULL DEFAULT 'rule_based',
    location ENUM('home','gym') NOT NULL DEFAULT 'home',
    est_duration_min SMALLINT UNSIGNED DEFAULT NULL,
    est_calories_burn INT UNSIGNED DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_wplan_user_date (user_id, plan_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE workout_plan_exercises (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    workout_plan_id BIGINT UNSIGNED NOT NULL,
    exercise_id BIGINT UNSIGNED NOT NULL,
    sets TINYINT UNSIGNED NOT NULL,
    reps VARCHAR(20) NOT NULL,
    rest_seconds SMALLINT UNSIGNED NOT NULL DEFAULT 60,
    sort_order TINYINT UNSIGNED NOT NULL DEFAULT 0,
    FOREIGN KEY (workout_plan_id) REFERENCES workout_plans(id) ON DELETE CASCADE,
    FOREIGN KEY (exercise_id) REFERENCES exercises(id) ON DELETE CASCADE,
    INDEX idx_wpe_plan (workout_plan_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE workout_sessions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    workout_plan_id BIGINT UNSIGNED DEFAULT NULL,
    started_at DATETIME NOT NULL,
    completed_at DATETIME DEFAULT NULL,
    duration_seconds INT UNSIGNED DEFAULT NULL,
    calories_burned INT UNSIGNED DEFAULT NULL,
    status ENUM('in_progress','completed','abandoned') NOT NULL DEFAULT 'in_progress',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (workout_plan_id) REFERENCES workout_plans(id) ON DELETE SET NULL,
    INDEX idx_wsession_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE water_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    log_date DATE NOT NULL,
    amount_ml INT UNSIGNED NOT NULL DEFAULT 0,
    goal_ml INT UNSIGNED NOT NULL DEFAULT 3000,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_water_user_date (user_id, log_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE sleep_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    log_date DATE NOT NULL,
    sleep_hours DECIMAL(4,2) NOT NULL,
    sleep_quality ENUM('poor','average','good','excellent') DEFAULT NULL,
    notes VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_sleep_user_date (user_id, log_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE health_scores (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    score_date DATE NOT NULL,
    diet_score TINYINT UNSIGNED DEFAULT 0,
    workout_score TINYINT UNSIGNED DEFAULT 0,
    sleep_score TINYINT UNSIGNED DEFAULT 0,
    water_score TINYINT UNSIGNED DEFAULT 0,
    total_score TINYINT UNSIGNED DEFAULT 0,
    suggestion TEXT DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_score_user_date (user_id, score_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE user_gamification (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL UNIQUE,
    xp_points INT UNSIGNED NOT NULL DEFAULT 0,
    level SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    current_streak_days INT UNSIGNED NOT NULL DEFAULT 0,
    longest_streak_days INT UNSIGNED NOT NULL DEFAULT 0,
    last_activity_date DATE DEFAULT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE badges (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    icon VARCHAR(255) DEFAULT NULL,
    criteria_type ENUM('streak','xp','workout_count','diet_count') NOT NULL,
    criteria_value INT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE user_badges (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    badge_id BIGINT UNSIGNED NOT NULL,
    earned_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (badge_id) REFERENCES badges(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_user_badge (user_id, badge_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE chat_conversations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(150) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_chat_conv_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE chat_messages (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    conversation_id BIGINT UNSIGNED NOT NULL,
    sender ENUM('user','ai') NOT NULL,
    message TEXT NOT NULL,
    tokens_used INT UNSIGNED DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES chat_conversations(id) ON DELETE CASCADE,
    INDEX idx_chat_msg_conv (conversation_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE subscription_plans (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    duration_days SMALLINT UNSIGNED NOT NULL,
    price_inr DECIMAL(8,2) NOT NULL,
    features TEXT DEFAULT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    sort_order TINYINT UNSIGNED DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE user_subscriptions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    plan_id BIGINT UNSIGNED NOT NULL,
    started_at DATETIME NOT NULL,
    expires_at DATETIME NOT NULL,
    status ENUM('active','expired','cancelled') NOT NULL DEFAULT 'active',
    assigned_by ENUM('purchase','admin') NOT NULL DEFAULT 'purchase',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (plan_id) REFERENCES subscription_plans(id) ON DELETE RESTRICT,
    INDEX idx_usersub_user (user_id),
    INDEX idx_usersub_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE transactions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    subscription_id BIGINT UNSIGNED DEFAULT NULL,
    order_id VARCHAR(100) NOT NULL,
    payment_id VARCHAR(100) DEFAULT NULL,
    amount_inr DECIMAL(8,2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'INR',
    status ENUM('pending','success','failed','refunded') NOT NULL DEFAULT 'pending',
    payment_gateway VARCHAR(50) NOT NULL DEFAULT 'razorpay',
    raw_response TEXT DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (subscription_id) REFERENCES user_subscriptions(id) ON DELETE SET NULL,
    INDEX idx_txn_user (user_id),
    INDEX idx_txn_order (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE user_credits (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL UNIQUE,
    balance INT NOT NULL DEFAULT 5,
    last_reset_date DATE DEFAULT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE credit_transactions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    change_amount INT NOT NULL,
    reason VARCHAR(150) NOT NULL,
    balance_after INT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_credittxn_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE ad_settings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ad_type ENUM('banner','interstitial','rewarded') NOT NULL,
    ad_unit_id VARCHAR(150) NOT NULL,
    platform ENUM('android','ios') NOT NULL DEFAULT 'android',
    is_enabled TINYINT(1) NOT NULL DEFAULT 1,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_ad_type_platform (ad_type, platform)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE ai_prompts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    prompt_key VARCHAR(100) NOT NULL UNIQUE,
    prompt_text TEXT NOT NULL,
    model_name VARCHAR(50) NOT NULL DEFAULT 'gemini-2.5-flash',
    max_tokens INT UNSIGNED NOT NULL DEFAULT 800,
    temperature DECIMAL(2,1) NOT NULL DEFAULT 0.7,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE feature_usage_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    feature_key VARCHAR(80) NOT NULL,
    used_ai TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_usage_feature_date (feature_key, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE admin_activity_log (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    admin_id BIGINT UNSIGNED NOT NULL,
    action VARCHAR(150) NOT NULL,
    target_type VARCHAR(50) DEFAULT NULL,
    target_id BIGINT UNSIGNED DEFAULT NULL,
    details TEXT DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_adminlog_admin (admin_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO subscription_plans (name, duration_days, price_inr, features, sort_order) VALUES
('Monthly Premium', 30, 149.00, '["no_ads","unlimited_chat","advanced_plans","food_photo_analysis","full_reports"]', 1),
('Quarterly Premium', 90, 399.00, '["no_ads","unlimited_chat","advanced_plans","food_photo_analysis","full_reports"]', 2);

INSERT INTO ai_prompts (prompt_key, prompt_text, model_name) VALUES
('chat_coach_system', 'You are a friendly Indian fitness and diet coach. Reply in Hinglish or English matching the user tone. Keep answers short, practical, and encouraging.', 'gemini-2.5-flash'),
('food_photo_analysis', 'Analyze this food image. Identify the dish, estimate calories and macros (protein, carbs, fat), and give a health score 0-100.', 'gemini-2.5-flash');

INSERT INTO ad_settings (ad_type, ad_unit_id, platform) VALUES
('banner', 'ca-app-pub-XXXXXXXXXXXXXXXX/BANNER_ID', 'android'),
('interstitial', 'ca-app-pub-XXXXXXXXXXXXXXXX/INTERSTITIAL_ID', 'android'),
('rewarded', 'ca-app-pub-XXXXXXXXXXXXXXXX/REWARDED_ID', 'android');

INSERT INTO badges (name, description, criteria_type, criteria_value) VALUES
('First Step', 'Complete your first workout', 'workout_count', 1),
('7-Day Warrior', 'Maintain a 7-day streak', 'streak', 7),
('30-Day Champion', 'Maintain a 30-day streak', 'streak', 30),
('Diet Starter', 'Log 5 diet plans', 'diet_count', 5),
('XP Master', 'Reach 1000 XP', 'xp', 1000);

-- Sample exercises seed
INSERT INTO exercises (name, category, muscle_group, equipment, goal_tag, default_sets, default_reps, rest_seconds, calories_burned_per_min, video_url) VALUES
('Push Ups', 'beginner', 'chest', 'none', 'all', 3, '10-15', 60, 7, 'https://example.com/pushups'),
('Squats', 'beginner', 'legs', 'none', 'all', 3, '15-20', 60, 8, 'https://example.com/squats'),
('Plank', 'beginner', 'core', 'none', 'all', 3, '30-45 sec', 45, 5, 'https://example.com/plank'),
('Jumping Jacks', 'beginner', 'cardio', 'none', 'weight_loss', 3, '30 sec', 30, 10, 'https://example.com/jumpingjacks'),
('Lunges', 'intermediate', 'legs', 'none', 'all', 3, '12-15', 60, 8, 'https://example.com/lunges'),
('Burpees', 'intermediate', 'full_body', 'none', 'weight_loss', 3, '10-12', 60, 12, 'https://example.com/burpees'),
('Dumbbell Bicep Curl', 'beginner', 'arms', 'gym', 'muscle_gain', 3, '10-12', 60, 5, 'https://example.com/curls'),
('Bench Press', 'intermediate', 'chest', 'gym', 'muscle_gain', 4, '8-10', 90, 6, 'https://example.com/benchpress'),
('Deadlift', 'advanced', 'back', 'gym', 'muscle_gain', 4, '6-8', 120, 8, 'https://example.com/deadlift'),
('Mountain Climbers', 'intermediate', 'cardio', 'none', 'weight_loss', 3, '20-30', 45, 10, 'https://example.com/mountainclimbers');
