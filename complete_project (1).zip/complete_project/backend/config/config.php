<?php
// ============================================================
// GLOBAL CONFIG — edit these values for your cPanel environment
// ============================================================

// Database
define('DB_HOST', 'localhost');
define('DB_NAME', 'your_cpanel_db_name');
define('DB_USER', 'your_cpanel_db_user');
define('DB_PASS', 'your_cpanel_db_password');

// JWT
define('JWT_SECRET', 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET_KEY');
define('JWT_ALGO', 'HS256');
define('JWT_ACCESS_TTL', 3600);        // 1 hour
define('JWT_REFRESH_TTL', 2592000);    // 30 days

// Mail (SMTP)
define('SMTP_HOST', 'mail.yourdomain.com');
define('SMTP_PORT', 465);
define('SMTP_USER', 'noreply@yourdomain.com');
define('SMTP_PASS', 'your_smtp_password');
define('SMTP_FROM', 'noreply@yourdomain.com');
define('SMTP_FROM_NAME', 'AI Fitness App');

// Gemini AI
define('GEMINI_API_KEY', 'YOUR_GEMINI_API_KEY');
define('GEMINI_MODEL', 'gemini-2.5-flash');
define('GEMINI_API_URL', 'https://generativelanguage.googleapis.com/v1beta/models/');

// Razorpay
define('RAZORPAY_KEY_ID', 'YOUR_RAZORPAY_KEY_ID');
define('RAZORPAY_KEY_SECRET', 'YOUR_RAZORPAY_KEY_SECRET');

// App
define('APP_ENV', 'production'); // production | development
define('FREE_DAILY_CREDITS', 5);
define('APP_TIMEZONE', 'Asia/Kolkata');

date_default_timezone_set(APP_TIMEZONE);
error_reporting(APP_ENV === 'development' ? E_ALL : 0);
ini_set('display_errors', APP_ENV === 'development' ? 1 : 0);
