<?php
require_once __DIR__ . '/../config/db.php';

/**
 * Checks if the given user currently has an active premium subscription.
 */
function is_premium(int $userId): bool {
    $stmt = DB::conn()->prepare(
        "SELECT id FROM user_subscriptions
         WHERE user_id = ? AND status = 'active' AND expires_at > NOW()
         LIMIT 1"
    );
    $stmt->execute([$userId]);
    return (bool) $stmt->fetch();
}

/**
 * Blocks the request unless the user is premium. Use for hard-locked features
 * (e.g. food photo analysis) where credits should NOT be an alternative.
 */
function require_premium(int $userId): void {
    if (!is_premium($userId)) {
        fail('This is a Premium-only feature. Please upgrade to continue.', 403);
    }
}
