<?php
require_once __DIR__ . '/../helpers/jwt.php';
require_once __DIR__ . '/../helpers/response.php';
require_once __DIR__ . '/../config/db.php';

/**
 * Validates JWT and returns authenticated user row.
 * Call at the top of any protected endpoint: $user = require_auth();
 */
function require_auth(): array {
    $token = JWT::getBearerToken();
    if (!$token) fail('Authorization token missing', 401);

    $payload = JWT::decode($token);
    if (!$payload || !isset($payload['user_id'])) fail('Invalid or expired token', 401);

    $stmt = DB::conn()->prepare("SELECT * FROM users WHERE id = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$payload['user_id']]);
    $user = $stmt->fetch();

    if (!$user) fail('User not found or blocked', 401);

    return $user;
}

function require_admin(): array {
    $user = require_auth();
    if ($user['role'] !== 'admin') fail('Admin access required', 403);
    return $user;
}
