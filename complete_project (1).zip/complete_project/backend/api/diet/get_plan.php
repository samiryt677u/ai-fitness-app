<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';

$user = require_auth();
$date = $_GET['date'] ?? date('Y-m-d');

$db = DB::conn();
$stmt = $db->prepare("SELECT * FROM diet_plans WHERE user_id = ? AND plan_date = ?");
$stmt->execute([$user['id'], $date]);
$plan = $stmt->fetch();

if (!$plan) fail('No diet plan found for this date', 404);

$meals = $db->prepare("SELECT * FROM diet_plan_meals WHERE diet_plan_id = ?");
$meals->execute([$plan['id']]);

success(['plan' => $plan, 'meals' => $meals->fetchAll()]);
