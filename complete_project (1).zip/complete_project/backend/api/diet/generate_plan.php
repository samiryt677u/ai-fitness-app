<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';
require_once __DIR__ . '/../../includes/RuleBasedDietEngine.php';
require_once __DIR__ . '/../../includes/GamificationManager.php';

$user = require_auth();
$db = DB::conn();

$stmt = $db->prepare("SELECT * FROM user_profiles WHERE user_id = ?");
$stmt->execute([$user['id']]);
$profile = $stmt->fetch();

if (!$profile || !$profile['tdee']) {
    fail('Please complete your profile (age, gender, height, weight) first', 422);
}

$today = date('Y-m-d');

// Return cached plan if already generated today
$stmt = $db->prepare("SELECT * FROM diet_plans WHERE user_id = ? AND plan_date = ?");
$stmt->execute([$user['id'], $today]);
$existing = $stmt->fetch();

if ($existing) {
    $meals = $db->prepare("SELECT * FROM diet_plan_meals WHERE diet_plan_id = ?");
    $meals->execute([$existing['id']]);
    success(['plan' => $existing, 'meals' => $meals->fetchAll()], 'Existing plan for today');
}

$result = RuleBasedDietEngine::generatePlan($profile);

$db->beginTransaction();
$stmt = $db->prepare(
    "INSERT INTO diet_plans (user_id, plan_date, source, total_calories, total_protein_g, total_carbs_g, total_fat_g)
     VALUES (?, ?, 'rule_based', ?, ?, ?, ?)"
);
$stmt->execute([$user['id'], $today, $result['total_calories'], $result['total_protein_g'], $result['total_carbs_g'], $result['total_fat_g']]);
$planId = (int) $db->lastInsertId();

$mealStmt = $db->prepare(
    "INSERT INTO diet_plan_meals (diet_plan_id, meal_type, food_items, calories, protein_g, carbs_g, fat_g, est_cost_inr)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
);
foreach ($result['meals'] as $meal) {
    $mealStmt->execute([
        $planId, $meal['meal_type'], json_encode($meal['food_items']),
        $meal['calories'], $meal['protein_g'], $meal['carbs_g'], $meal['fat_g'], $meal['est_cost_inr'],
    ]);
}
$db->commit();

$db->prepare("INSERT INTO feature_usage_logs (user_id, feature_key, used_ai) VALUES (?, 'diet_plan', 0)")->execute([$user['id']]);
GamificationManager::recordActivity($user['id'], 'diet_logged');

success([
    'plan_id' => $planId,
    'total_calories' => $result['total_calories'],
    'total_protein_g' => $result['total_protein_g'],
    'total_carbs_g' => $result['total_carbs_g'],
    'total_fat_g' => $result['total_fat_g'],
    'meals' => $result['meals'],
], 'Diet plan generated', 201);
