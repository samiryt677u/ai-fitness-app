<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';
require_once __DIR__ . '/../../includes/GamificationManager.php';

$user = require_auth();
$input = get_json_input();
require_fields($input, ['session_id']);

$db = DB::conn();
$stmt = $db->prepare("SELECT * FROM workout_sessions WHERE id = ? AND user_id = ?");
$stmt->execute([$input['session_id'], $user['id']]);
$session = $stmt->fetch();
if (!$session) fail('Session not found', 404);

$duration = time() - strtotime($session['started_at']);
$calories = $input['calories_burned'] ?? round($duration / 60 * 6);

$db->prepare(
    "UPDATE workout_sessions SET completed_at = NOW(), duration_seconds = ?, calories_burned = ?, status = 'completed' WHERE id = ?"
)->execute([$duration, $calories, $session['id']]);

$db->prepare("INSERT INTO feature_usage_logs (user_id, feature_key, used_ai) VALUES (?, 'workout_session', 0)")->execute([$user['id']]);
GamificationManager::recordActivity($user['id'], 'workout_complete');

success(['duration_seconds' => $duration, 'calories_burned' => (int) $calories], 'Workout completed! XP awarded.');
