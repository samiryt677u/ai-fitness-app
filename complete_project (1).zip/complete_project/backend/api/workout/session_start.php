<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';

$user = require_auth();
$input = get_json_input();

$db = DB::conn();
$stmt = $db->prepare(
    "INSERT INTO workout_sessions (user_id, workout_plan_id, started_at, status) VALUES (?, ?, NOW(), 'in_progress')"
);
$stmt->execute([$user['id'], $input['workout_plan_id'] ?? null]);

success(['session_id' => (int) $db->lastInsertId()], 'Workout session started', 201);
