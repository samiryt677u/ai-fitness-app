<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';
require_once __DIR__ . '/../../includes/RuleBasedWorkoutEngine.php';

$user = require_auth();
$db = DB::conn();

$stmt = $db->prepare("SELECT * FROM user_profiles WHERE user_id = ?");
$stmt->execute([$user['id']]);
$profile = $stmt->fetch();

if (!$profile) fail('Please complete your profile first', 422);

$today = date('Y-m-d');
$stmt = $db->prepare("SELECT * FROM workout_plans WHERE user_id = ? AND plan_date = ?");
$stmt->execute([$user['id'], $today]);
$existing = $stmt->fetch();

if ($existing) {
    $ex = $db->prepare(
        "SELECT wpe.*, e.name, e.video_url FROM workout_plan_exercises wpe
         JOIN exercises e ON e.id = wpe.exercise_id
         WHERE wpe.workout_plan_id = ? ORDER BY wpe.sort_order"
    );
    $ex->execute([$existing['id']]);
    success(['plan' => $existing, 'exercises' => $ex->fetchAll()], 'Existing plan for today');
}

$result = RuleBasedWorkoutEngine::generatePlan($profile);

$db->beginTransaction();
$stmt = $db->prepare(
    "INSERT INTO workout_plans (user_id, plan_date, source, location, est_duration_min, est_calories_burn)
     VALUES (?, ?, 'rule_based', ?, ?, ?)"
);
$stmt->execute([$user['id'], $today, $result['location'], $result['est_duration_min'], $result['est_calories_burn']]);
$planId = (int) $db->lastInsertId();

$exStmt = $db->prepare(
    "INSERT INTO workout_plan_exercises (workout_plan_id, exercise_id, sets, reps, rest_seconds, sort_order)
     VALUES (?, ?, ?, ?, ?, ?)"
);
foreach ($result['exercises'] as $ex) {
    $exStmt->execute([$planId, $ex['exercise_id'], $ex['sets'], $ex['reps'], $ex['rest_seconds'], $ex['sort_order']]);
}
$db->commit();

$db->prepare("INSERT INTO feature_usage_logs (user_id, feature_key, used_ai) VALUES (?, 'workout_plan', 0)")->execute([$user['id']]);

success(['plan_id' => $planId, 'result' => $result], 'Workout plan generated', 201);
