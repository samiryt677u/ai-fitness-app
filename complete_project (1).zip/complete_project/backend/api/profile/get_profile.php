<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';

$user = require_auth();

$stmt = DB::conn()->prepare("SELECT * FROM user_profiles WHERE user_id = ?");
$stmt->execute([$user['id']]);
$profile = $stmt->fetch();

success([
    'user' => [
        'id' => $user['id'],
        'name' => $user['name'],
        'email' => $user['email'],
        'phone' => $user['phone'],
        'profile_photo' => $user['profile_photo'],
        'email_verified' => (bool) $user['email_verified'],
    ],
    'profile' => $profile,
]);
