<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';
require_once __DIR__ . '/../../includes/RuleBasedDietEngine.php';

$user = require_auth();
$input = get_json_input();

$allowed = ['age','gender','height_cm','weight_kg','target_weight_kg','goal',
    'activity_level','diet_preference','fitness_level','workout_location','budget_preference'];

$fields = [];
$values = [];
foreach ($allowed as $key) {
    if (isset($input[$key])) {
        $fields[] = "$key = ?";
        $values[] = $input[$key];
    }
}

if (empty($fields)) fail('No valid fields to update', 422);

// Recalculate BMR/TDEE if relevant fields changed
$db = DB::conn();
$stmt = $db->prepare("SELECT * FROM user_profiles WHERE user_id = ?");
$stmt->execute([$user['id']]);
$current = $stmt->fetch();
$merged = array_merge($current, $input);

if (!empty($merged['age']) && !empty($merged['gender']) && !empty($merged['height_cm']) && !empty($merged['weight_kg'])) {
    $bmr = RuleBasedDietEngine::calculateBMR($merged['gender'], $merged['weight_kg'], $merged['height_cm'], $merged['age']);
    $tdee = RuleBasedDietEngine::calculateTDEE($bmr, $merged['activity_level'] ?? 'moderate');
    $fields[] = "bmr = ?";
    $values[] = $bmr;
    $fields[] = "tdee = ?";
    $values[] = $tdee;
}

$values[] = $user['id'];
$sql = "UPDATE user_profiles SET " . implode(', ', $fields) . " WHERE user_id = ?";
$db->prepare($sql)->execute($values);

success([], 'Profile updated successfully');
