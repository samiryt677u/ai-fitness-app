<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';

$user = require_auth();
$db = DB::conn();

$stmt = $db->prepare("SELECT * FROM user_gamification WHERE user_id = ?");
$stmt->execute([$user['id']]);
$g = $stmt->fetch();

$badges = $db->prepare(
    "SELECT b.* FROM user_badges ub JOIN badges b ON b.id = ub.badge_id WHERE ub.user_id = ? ORDER BY ub.earned_at DESC"
);
$badges->execute([$user['id']]);

success([
    'xp_points' => (int) $g['xp_points'],
    'level' => (int) $g['level'],
    'current_streak_days' => (int) $g['current_streak_days'],
    'longest_streak_days' => (int) $g['longest_streak_days'],
    'xp_to_next_level' => 500 - ($g['xp_points'] % 500),
    'badges' => $badges->fetchAll(),
]);
