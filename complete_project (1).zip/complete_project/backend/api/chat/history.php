<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';

$user = require_auth();
$db = DB::conn();

if (isset($_GET['conversation_id'])) {
    $check = $db->prepare("SELECT id FROM chat_conversations WHERE id = ? AND user_id = ?");
    $check->execute([$_GET['conversation_id'], $user['id']]);
    if (!$check->fetch()) fail('Conversation not found', 404);

    $stmt = $db->prepare("SELECT * FROM chat_messages WHERE conversation_id = ? ORDER BY created_at ASC");
    $stmt->execute([$_GET['conversation_id']]);
    success(['messages' => $stmt->fetchAll()]);
}

$stmt = $db->prepare("SELECT * FROM chat_conversations WHERE user_id = ? ORDER BY updated_at DESC LIMIT 50");
$stmt->execute([$user['id']]);
success(['conversations' => $stmt->fetchAll()]);
