<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';
require_once __DIR__ . '/../../middleware/premium_middleware.php';
require_once __DIR__ . '/../../includes/GeminiClient.php';
require_once __DIR__ . '/../../includes/CreditManager.php';
require_once __DIR__ . '/../../includes/GamificationManager.php';

$user = require_auth();
$input = get_json_input();
require_fields($input, ['message']);

$db = DB::conn();
$premium = is_premium($user['id']);

// Free users: deduct 1 credit per message. Premium: unlimited.
if (!$premium) {
    if (!CreditManager::deduct($user['id'], 1, 'chat_message')) {
        fail('Daily free AI credits exhausted. Upgrade to Premium for unlimited chat, or watch a rewarded ad for more credits.', 402);
    }
}

// Get or create conversation
$conversationId = $input['conversation_id'] ?? null;
if (!$conversationId) {
    $db->prepare("INSERT INTO chat_conversations (user_id, title) VALUES (?, ?)")
       ->execute([$user['id'], substr($input['message'], 0, 60)]);
    $conversationId = (int) $db->lastInsertId();
} else {
    $check = $db->prepare("SELECT id FROM chat_conversations WHERE id = ? AND user_id = ?");
    $check->execute([$conversationId, $user['id']]);
    if (!$check->fetch()) fail('Conversation not found', 404);
}

$db->prepare("INSERT INTO chat_messages (conversation_id, sender, message) VALUES (?, 'user', ?)")
   ->execute([$conversationId, $input['message']]);

// Fetch system prompt from DB (admin-editable)
$promptStmt = $db->prepare("SELECT * FROM ai_prompts WHERE prompt_key = 'chat_coach_system' AND is_active = 1");
$promptStmt->execute();
$promptRow = $promptStmt->fetch();
$systemPrompt = $promptRow['prompt_text'] ?? 'You are a helpful fitness and diet coach. Reply in Hinglish or English matching user tone.';

$result = GeminiClient::generateText($systemPrompt, $input['message'], (int) ($promptRow['max_tokens'] ?? 500), (float) ($promptRow['temperature'] ?? 0.7));

if (!$result['success']) {
    // Refund credit on AI failure
    if (!$premium) CreditManager::addCredits($user['id'], 1, 'refund_ai_failure');
    fail('AI Coach is temporarily unavailable. Please try again in a moment.', 503);
}

$db->prepare("INSERT INTO chat_messages (conversation_id, sender, message, tokens_used) VALUES (?, 'ai', ?, ?)")
   ->execute([$conversationId, $result['text'], $result['tokens']]);

$db->prepare("INSERT INTO feature_usage_logs (user_id, feature_key, used_ai) VALUES (?, 'chat', 1)")->execute([$user['id']]);
GamificationManager::recordActivity($user['id'], 'chat_used');

success([
    'conversation_id' => $conversationId,
    'reply' => $result['text'],
    'credits_remaining' => $premium ? null : CreditManager::getBalance($user['id']),
], 'Reply generated');
