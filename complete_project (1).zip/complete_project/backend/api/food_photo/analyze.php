<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';
require_once __DIR__ . '/../../middleware/premium_middleware.php';
require_once __DIR__ . '/../../includes/GeminiClient.php';

$user = require_auth();
require_premium($user['id']); // hard-locked premium feature

if (empty($_FILES['image'])) fail('No image uploaded', 422);

$file = $_FILES['image'];
$allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
if (!in_array($file['type'], $allowedTypes)) fail('Only JPEG, PNG, WEBP images allowed', 422);
if ($file['size'] > 5 * 1024 * 1024) fail('Image too large (max 5MB)', 422);

$uploadDir = __DIR__ . '/../../uploads/food_photos/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

$filename = uniqid('food_') . '_' . $user['id'] . '.jpg';
$filepath = $uploadDir . $filename;
move_uploaded_file($file['tmp_name'], $filepath);

$base64 = base64_encode(file_get_contents($filepath));

$db = DB::conn();
$promptStmt = $db->prepare("SELECT * FROM ai_prompts WHERE prompt_key = 'food_photo_analysis' AND is_active = 1");
$promptStmt->execute();
$promptRow = $promptStmt->fetch();
$systemPrompt = ($promptRow['prompt_text'] ?? 'Analyze this food image. Return calories and macros.') .
    ' Respond ONLY in strict JSON format: {"food_name": "", "calories": 0, "protein_g": 0, "carbs_g": 0, "fat_g": 0, "health_score": 0}';

$result = GeminiClient::analyzeImage($systemPrompt, $base64, $file['type'], (int) ($promptRow['max_tokens'] ?? 400));

if (!$result['success']) fail('AI analysis temporarily unavailable. Please try again.', 503);

// Parse JSON from AI response (strip markdown fences if present)
$clean = preg_replace('/```json|```/', '', $result['text']);
$parsed = json_decode(trim($clean), true);

if (!$parsed) fail('Could not parse food analysis. Please try a clearer image.', 500);

$stmt = $db->prepare(
    "INSERT INTO food_photo_analysis (user_id, image_path, detected_food, calories, protein_g, carbs_g, fat_g, health_score, ai_raw_response)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
);
$stmt->execute([
    $user['id'], 'uploads/food_photos/' . $filename, $parsed['food_name'] ?? 'Unknown',
    $parsed['calories'] ?? 0, $parsed['protein_g'] ?? 0, $parsed['carbs_g'] ?? 0,
    $parsed['fat_g'] ?? 0, $parsed['health_score'] ?? 0, $result['text'],
]);

$db->prepare("INSERT INTO feature_usage_logs (user_id, feature_key, used_ai) VALUES (?, 'food_photo', 1)")->execute([$user['id']]);

success([
    'food_name' => $parsed['food_name'] ?? 'Unknown',
    'calories' => $parsed['calories'] ?? 0,
    'protein_g' => $parsed['protein_g'] ?? 0,
    'carbs_g' => $parsed['carbs_g'] ?? 0,
    'fat_g' => $parsed['fat_g'] ?? 0,
    'health_score' => $parsed['health_score'] ?? 0,
], 'Food analyzed successfully');
