<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';

$user = require_auth();
$input = get_json_input();
require_fields($input, ['plan_id']);

$db = DB::conn();
$stmt = $db->prepare("SELECT * FROM subscription_plans WHERE id = ? AND is_active = 1");
$stmt->execute([$input['plan_id']]);
$plan = $stmt->fetch();
if (!$plan) fail('Invalid plan', 404);

$amountPaise = (int) round($plan['price_inr'] * 100);

$ch = curl_init('https://api.razorpay.com/v1/orders');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_USERPWD => RAZORPAY_KEY_ID . ':' . RAZORPAY_KEY_SECRET,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode([
        'amount' => $amountPaise,
        'currency' => 'INR',
        'receipt' => 'user_' . $user['id'] . '_' . time(),
        'notes' => ['user_id' => $user['id'], 'plan_id' => $plan['id']],
    ]),
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) fail('Could not create payment order', 502);

$order = json_decode($response, true);

success([
    'order_id' => $order['id'],
    'amount' => $amountPaise,
    'currency' => 'INR',
    'razorpay_key' => RAZORPAY_KEY_ID,
    'plan_name' => $plan['name'],
], 'Order created');
