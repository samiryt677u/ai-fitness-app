<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../helpers/response.php';

$stmt = DB::conn()->query("SELECT * FROM subscription_plans WHERE is_active = 1 ORDER BY sort_order");
success(['plans' => $stmt->fetchAll()]);
