<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';

$user = require_auth();
$input = get_json_input();
require_fields($input, ['plan_id', 'razorpay_order_id', 'razorpay_payment_id', 'razorpay_signature']);

// Verify Razorpay signature: HMAC_SHA256(order_id + "|" + payment_id, key_secret)
$generatedSignature = hash_hmac(
    'sha256',
    $input['razorpay_order_id'] . '|' . $input['razorpay_payment_id'],
    RAZORPAY_KEY_SECRET
);

if (!hash_equals($generatedSignature, $input['razorpay_signature'])) {
    fail('Payment verification failed', 400);
}

$db = DB::conn();
$stmt = $db->prepare("SELECT * FROM subscription_plans WHERE id = ? AND is_active = 1");
$stmt->execute([$input['plan_id']]);
$plan = $stmt->fetch();
if (!$plan) fail('Invalid subscription plan', 404);

$db->beginTransaction();
try {
    $stmt = $db->prepare(
        "INSERT INTO user_subscriptions (user_id, plan_id, started_at, expires_at, status, assigned_by)
         VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL ? DAY), 'active', 'purchase')"
    );
    $stmt->execute([$user['id'], $plan['id'], $plan['duration_days']]);
    $subId = (int) $db->lastInsertId();

    $db->prepare(
        "INSERT INTO transactions (user_id, subscription_id, order_id, payment_id, amount_inr, status, payment_gateway)
         VALUES (?, ?, ?, ?, ?, 'success', 'razorpay')"
    )->execute([$user['id'], $subId, $input['razorpay_order_id'], $input['razorpay_payment_id'], $plan['price_inr']]);

    $db->commit();
} catch (Exception $e) {
    $db->rollBack();
    fail('Failed to activate subscription', 500);
}

success(['subscription_id' => $subId, 'expires_at_days' => $plan['duration_days']], 'Premium activated successfully!');
