<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';
require_once __DIR__ . '/../../middleware/premium_middleware.php';
require_once __DIR__ . '/../../includes/CreditManager.php';

$user = require_auth();

success([
    'balance' => CreditManager::getBalance($user['id']),
    'is_premium' => is_premium($user['id']),
    'daily_free_credits' => FREE_DAILY_CREDITS,
]);
