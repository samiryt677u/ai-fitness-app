<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';
require_once __DIR__ . '/../../includes/GamificationManager.php';

$user = require_auth();
$db = DB::conn();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $date = $_GET['date'] ?? date('Y-m-d');
    $stmt = $db->prepare("SELECT * FROM water_logs WHERE user_id = ? AND log_date = ?");
    $stmt->execute([$user['id'], $date]);
    $row = $stmt->fetch();
    success(['log' => $row ?: ['amount_ml' => 0, 'goal_ml' => 3000]]);
}

if ($method === 'POST') {
    $input = get_json_input();
    require_fields($input, ['amount_ml']);
    $today = date('Y-m-d');

    $stmt = $db->prepare(
        "INSERT INTO water_logs (user_id, log_date, amount_ml, goal_ml)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE amount_ml = amount_ml + VALUES(amount_ml)"
    );
    $stmt->execute([$user['id'], $today, $input['amount_ml'], $input['goal_ml'] ?? 3000]);

    $check = $db->prepare("SELECT * FROM water_logs WHERE user_id = ? AND log_date = ?");
    $check->execute([$user['id'], $today]);
    $row = $check->fetch();

    if ($row['amount_ml'] >= $row['goal_ml']) {
        GamificationManager::recordActivity($user['id'], 'water_goal_met');
    }

    success(['log' => $row], 'Water intake logged');
}

fail('Method not allowed', 405);
