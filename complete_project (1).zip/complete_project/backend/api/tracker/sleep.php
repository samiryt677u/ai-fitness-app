<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';
require_once __DIR__ . '/../../includes/GamificationManager.php';

$user = require_auth();
$db = DB::conn();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $date = $_GET['date'] ?? date('Y-m-d');
    $stmt = $db->prepare("SELECT * FROM sleep_logs WHERE user_id = ? AND log_date = ?");
    $stmt->execute([$user['id'], $date]);
    success(['log' => $stmt->fetch() ?: null]);
}

if ($method === 'POST') {
    $input = get_json_input();
    require_fields($input, ['sleep_hours']);
    $today = date('Y-m-d');

    $stmt = $db->prepare(
        "INSERT INTO sleep_logs (user_id, log_date, sleep_hours, sleep_quality, notes)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE sleep_hours = VALUES(sleep_hours), sleep_quality = VALUES(sleep_quality), notes = VALUES(notes)"
    );
    $stmt->execute([$user['id'], $today, $input['sleep_hours'], $input['sleep_quality'] ?? null, $input['notes'] ?? null]);

    $suggestion = $input['sleep_hours'] < 6
        ? 'You are sleeping less than recommended. Try to get 7-8 hours for better recovery.'
        : (($input['sleep_hours'] > 9) ? 'Oversleeping can affect energy levels. Aim for 7-8 hours.' : 'Great! Your sleep duration is in a healthy range.');

    GamificationManager::recordActivity($user['id'], 'sleep_logged');

    success(['suggestion' => $suggestion], 'Sleep logged');
}

fail('Method not allowed', 405);
