<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';

$user = require_auth();
$db = DB::conn();
$today = date('Y-m-d');

// Diet score: was a plan generated & (roughly) followed today
$stmt = $db->prepare("SELECT COUNT(*) FROM diet_plans WHERE user_id = ? AND plan_date = ?");
$stmt->execute([$user['id'], $today]);
$dietScore = $stmt->fetchColumn() > 0 ? 100 : 0;

// Workout score: based on completed sessions today
$stmt = $db->prepare("SELECT COUNT(*) FROM workout_sessions WHERE user_id = ? AND DATE(started_at) = ? AND status = 'completed'");
$stmt->execute([$user['id'], $today]);
$workoutScore = $stmt->fetchColumn() > 0 ? 100 : 0;

// Sleep score: 7-9 hours ideal
$stmt = $db->prepare("SELECT sleep_hours FROM sleep_logs WHERE user_id = ? AND log_date = ?");
$stmt->execute([$user['id'], $today]);
$sleepHours = $stmt->fetchColumn();
$sleepScore = 0;
if ($sleepHours !== false) {
    $sleepScore = ($sleepHours >= 7 && $sleepHours <= 9) ? 100 : max(0, 100 - abs(8 - $sleepHours) * 20);
}

// Water score: % of goal met
$stmt = $db->prepare("SELECT amount_ml, goal_ml FROM water_logs WHERE user_id = ? AND log_date = ?");
$stmt->execute([$user['id'], $today]);
$water = $stmt->fetch();
$waterScore = $water ? min(100, round(($water['amount_ml'] / max($water['goal_ml'], 1)) * 100)) : 0;

$totalScore = round(($dietScore + $workoutScore + $sleepScore + $waterScore) / 4);

$suggestions = [];
if ($dietScore < 100) $suggestions[] = 'Generate and follow your diet plan today.';
if ($workoutScore < 100) $suggestions[] = 'Complete a workout session to boost your score.';
if ($sleepScore < 70) $suggestions[] = 'Try to get 7-9 hours of sleep tonight.';
if ($waterScore < 70) $suggestions[] = 'Drink more water — you are below your daily goal.';
$suggestionText = empty($suggestions) ? 'Great job! Keep up the healthy routine.' : implode(' ', $suggestions);

$db->prepare(
    "INSERT INTO health_scores (user_id, score_date, diet_score, workout_score, sleep_score, water_score, total_score, suggestion)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE diet_score=VALUES(diet_score), workout_score=VALUES(workout_score),
     sleep_score=VALUES(sleep_score), water_score=VALUES(water_score), total_score=VALUES(total_score), suggestion=VALUES(suggestion)"
)->execute([$user['id'], $today, $dietScore, $workoutScore, $sleepScore, $waterScore, $totalScore, $suggestionText]);

success([
    'diet_score' => $dietScore, 'workout_score' => $workoutScore,
    'sleep_score' => $sleepScore, 'water_score' => $waterScore,
    'total_score' => $totalScore, 'suggestion' => $suggestionText,
]);
