<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../helpers/response.php';
require_once __DIR__ . '/../../helpers/jwt.php';

$input = get_json_input();
require_fields($input, ['name', 'email', 'password']);

$name = trim($input['name']);
$email = strtolower(trim($input['email']));
$password = $input['password'];

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Invalid email address', 422);
if (strlen($password) < 6) fail('Password must be at least 6 characters', 422);

$db = DB::conn();

$check = $db->prepare("SELECT id FROM users WHERE email = ?");
$check->execute([$email]);
if ($check->fetch()) fail('Email already registered', 409);

$hash = password_hash($password, PASSWORD_BCRYPT);
$verifyToken = bin2hex(random_bytes(32));

$db->beginTransaction();
try {
    $stmt = $db->prepare(
        "INSERT INTO users (name, email, password_hash, email_verify_token) VALUES (?, ?, ?, ?)"
    );
    $stmt->execute([$name, $email, $hash, $verifyToken]);
    $userId = (int) $db->lastInsertId();

    // Initialize related rows
    $db->prepare("INSERT INTO user_profiles (user_id) VALUES (?)")->execute([$userId]);
    $db->prepare("INSERT INTO user_gamification (user_id) VALUES (?)")->execute([$userId]);
    $db->prepare("INSERT INTO user_credits (user_id, balance, last_reset_date) VALUES (?, ?, CURDATE())")
       ->execute([$userId, FREE_DAILY_CREDITS]);

    $db->commit();
} catch (Exception $e) {
    $db->rollBack();
    fail('Signup failed, please try again', 500);
}

// TODO: send verification email using mail_helper.php (see verify_email.php for token flow)

$accessToken = JWT::encode(['user_id' => $userId, 'role' => 'user'], JWT_ACCESS_TTL);
$refreshToken = JWT::encode(['user_id' => $userId, 'type' => 'refresh'], JWT_REFRESH_TTL);

$db->prepare("INSERT INTO user_sessions (user_id, refresh_token, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))")
   ->execute([$userId, $refreshToken]);

success([
    'user_id' => $userId,
    'name' => $name,
    'email' => $email,
    'access_token' => $accessToken,
    'refresh_token' => $refreshToken,
], 'Signup successful', 201);
