<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../helpers/response.php';

$input = get_json_input();
require_fields($input, ['token']);

$db = DB::conn();
$stmt = $db->prepare("SELECT id FROM users WHERE email_verify_token = ?");
$stmt->execute([$input['token']]);
$user = $stmt->fetch();

if (!$user) fail('Invalid verification token', 400);

$db->prepare("UPDATE users SET email_verified = 1, email_verify_token = NULL WHERE id = ?")
   ->execute([$user['id']]);

success([], 'Email verified successfully');
