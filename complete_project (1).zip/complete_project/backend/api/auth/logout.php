<?php
require_once __DIR__ . '/../../middleware/auth_middleware.php';

$user = require_auth();
$input = get_json_input();

if (!empty($input['refresh_token'])) {
    DB::conn()->prepare("DELETE FROM user_sessions WHERE user_id = ? AND refresh_token = ?")
        ->execute([$user['id'], $input['refresh_token']]);
} else {
    // logout from all devices if no specific token given
    DB::conn()->prepare("DELETE FROM user_sessions WHERE user_id = ?")->execute([$user['id']]);
}

success([], 'Logged out successfully');
