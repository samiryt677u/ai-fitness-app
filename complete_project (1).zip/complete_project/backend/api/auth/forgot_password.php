<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../helpers/response.php';

$input = get_json_input();
require_fields($input, ['email']);
$email = strtolower(trim($input['email']));

$db = DB::conn();
$stmt = $db->prepare("SELECT id, name FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

// Always respond success (don't leak whether email exists)
if ($user) {
    $token = bin2hex(random_bytes(32));
    $db->prepare("UPDATE users SET password_reset_token = ?, password_reset_expires = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE id = ?")
       ->execute([$token, $user['id']]);

    // TODO: integrate mail_helper.php to send reset link:
    // https://yourdomain.com/reset-password?token=$token
}

success([], 'If this email is registered, a reset link has been sent');
