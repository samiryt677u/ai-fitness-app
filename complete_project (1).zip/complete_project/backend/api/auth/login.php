<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../helpers/response.php';
require_once __DIR__ . '/../../helpers/jwt.php';

$input = get_json_input();
require_fields($input, ['email', 'password']);

$email = strtolower(trim($input['email']));
$password = $input['password'];

$db = DB::conn();
$stmt = $db->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    fail('Invalid email or password', 401);
}

if ($user['status'] === 'blocked') fail('Your account has been blocked. Contact support.', 403);

$accessToken = JWT::encode(['user_id' => $user['id'], 'role' => $user['role']], JWT_ACCESS_TTL);
$refreshToken = JWT::encode(['user_id' => $user['id'], 'type' => 'refresh'], JWT_REFRESH_TTL);

$db->prepare("INSERT INTO user_sessions (user_id, refresh_token, ip_address, expires_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))")
   ->execute([$user['id'], $refreshToken, $_SERVER['REMOTE_ADDR'] ?? null]);

$db->prepare("UPDATE users SET last_login_at = NOW() WHERE id = ?")->execute([$user['id']]);

success([
    'user_id' => $user['id'],
    'name' => $user['name'],
    'email' => $user['email'],
    'role' => $user['role'],
    'email_verified' => (bool) $user['email_verified'],
    'access_token' => $accessToken,
    'refresh_token' => $refreshToken,
], 'Login successful');
