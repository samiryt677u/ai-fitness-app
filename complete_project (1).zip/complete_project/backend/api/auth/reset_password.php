<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../helpers/response.php';

$input = get_json_input();
require_fields($input, ['token', 'new_password']);

if (strlen($input['new_password']) < 6) fail('Password must be at least 6 characters', 422);

$db = DB::conn();
$stmt = $db->prepare("SELECT id FROM users WHERE password_reset_token = ? AND password_reset_expires > NOW()");
$stmt->execute([$input['token']]);
$user = $stmt->fetch();

if (!$user) fail('Invalid or expired reset token', 400);

$hash = password_hash($input['new_password'], PASSWORD_BCRYPT);
$db->prepare("UPDATE users SET password_hash = ?, password_reset_token = NULL, password_reset_expires = NULL WHERE id = ?")
   ->execute([$hash, $user['id']]);

// Invalidate all existing sessions for security
$db->prepare("DELETE FROM user_sessions WHERE user_id = ?")->execute([$user['id']]);

success([], 'Password reset successful. Please log in again.');
