<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../helpers/response.php';

$db = DB::conn();
$category = $_GET['category'] ?? null;
$goal = $_GET['goal'] ?? null;
$equipment = $_GET['equipment'] ?? null;

$sql = "SELECT * FROM exercises WHERE 1=1";
$params = [];

if ($category) { $sql .= " AND category = ?"; $params[] = $category; }
if ($goal) { $sql .= " AND (goal_tag = ? OR goal_tag = 'all')"; $params[] = $goal; }
if ($equipment) { $sql .= " AND equipment IN (?, 'none')"; $params[] = $equipment; }

$sql .= " ORDER BY category, name";
$stmt = $db->prepare($sql);
$stmt->execute($params);

success(['exercises' => $stmt->fetchAll()]);
