<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/config.php';

/**
 * Manages per-user AI credit balance. Free daily credits reset every day;
 * premium users bypass credit checks entirely (unlimited, checked separately).
 */
class CreditManager {

    public static function getBalance(int $userId): int {
        self::resetIfNeeded($userId);
        $stmt = DB::conn()->prepare("SELECT balance FROM user_credits WHERE user_id = ?");
        $stmt->execute([$userId]);
        $row = $stmt->fetch();
        return $row ? (int) $row['balance'] : 0;
    }

    private static function resetIfNeeded(int $userId): void {
        $db = DB::conn();
        $stmt = $db->prepare("SELECT last_reset_date FROM user_credits WHERE user_id = ?");
        $stmt->execute([$userId]);
        $row = $stmt->fetch();

        if ($row && $row['last_reset_date'] !== date('Y-m-d')) {
            $db->prepare("UPDATE user_credits SET balance = ?, last_reset_date = CURDATE() WHERE user_id = ?")
               ->execute([FREE_DAILY_CREDITS, $userId]);
        }
    }

    /**
     * Attempts to deduct credits. Returns false if insufficient balance.
     */
    public static function deduct(int $userId, int $amount, string $reason): bool {
        self::resetIfNeeded($userId);
        $db = DB::conn();

        $db->beginTransaction();
        $stmt = $db->prepare("SELECT balance FROM user_credits WHERE user_id = ? FOR UPDATE");
        $stmt->execute([$userId]);
        $row = $stmt->fetch();

        if (!$row || $row['balance'] < $amount) {
            $db->rollBack();
            return false;
        }

        $newBalance = $row['balance'] - $amount;
        $db->prepare("UPDATE user_credits SET balance = ? WHERE user_id = ?")->execute([$newBalance, $userId]);
        $db->prepare("INSERT INTO credit_transactions (user_id, change_amount, reason, balance_after) VALUES (?, ?, ?, ?)")
           ->execute([$userId, -$amount, $reason, $newBalance]);

        $db->commit();
        return true;
    }

    public static function addCredits(int $userId, int $amount, string $reason): void {
        $db = DB::conn();
        $db->prepare("UPDATE user_credits SET balance = balance + ? WHERE user_id = ?")->execute([$amount, $userId]);
        $stmt = $db->prepare("SELECT balance FROM user_credits WHERE user_id = ?");
        $stmt->execute([$userId]);
        $balance = $stmt->fetchColumn();
        $db->prepare("INSERT INTO credit_transactions (user_id, change_amount, reason, balance_after) VALUES (?, ?, ?, ?)")
           ->execute([$userId, $amount, $reason, $balance]);
    }
}
