<?php
require_once __DIR__ . '/../config/db.php';

/**
 * Formula-based diet plan generator — zero AI cost.
 * Used for all free-tier users and as the default for everyone.
 */
class RuleBasedDietEngine {

    public static function calculateBMR(string $gender, float $weightKg, float $heightCm, int $age): float {
        // Mifflin-St Jeor Equation
        if ($gender === 'male') {
            return (10 * $weightKg) + (6.25 * $heightCm) - (5 * $age) + 5;
        }
        return (10 * $weightKg) + (6.25 * $heightCm) - (5 * $age) - 161;
    }

    public static function calculateTDEE(float $bmr, string $activityLevel): float {
        $multipliers = [
            'sedentary' => 1.2,
            'light' => 1.375,
            'moderate' => 1.55,
            'active' => 1.725,
            'very_active' => 1.9,
        ];
        return round($bmr * ($multipliers[$activityLevel] ?? 1.55));
    }

    /**
     * Adjust TDEE based on goal and split into macros + meals.
     */
    public static function generatePlan(array $profile): array {
        $tdee = (float) $profile['tdee'];
        $goal = $profile['goal'] ?? 'maintain_fitness';

        $targetCalories = match ($goal) {
            'weight_loss' => round($tdee * 0.80),   // ~20% deficit
            'muscle_gain' => round($tdee * 1.12),   // ~12% surplus
            default => round($tdee),
        };

        // Macro split (g/kg body weight approach for protein, remainder split carbs/fat)
        $weight = (float) $profile['weight_kg'];
        $proteinG = match ($goal) {
            'muscle_gain' => round($weight * 1.8),
            'weight_loss' => round($weight * 1.6),
            default => round($weight * 1.2),
        };
        $proteinCal = $proteinG * 4;
        $fatCal = round($targetCalories * 0.25);
        $fatG = round($fatCal / 9);
        $carbCal = $targetCalories - $proteinCal - $fatCal;
        $carbG = round(max($carbCal, 0) / 4);

        $meals = self::buildMeals($targetCalories, $profile['diet_preference'] ?? 'veg', $profile['budget_preference'] ?? 'medium');

        return [
            'total_calories' => (int) $targetCalories,
            'total_protein_g' => $proteinG,
            'total_carbs_g' => $carbG,
            'total_fat_g' => $fatG,
            'meals' => $meals,
        ];
    }

    /**
     * Distributes calories across breakfast/lunch/dinner/snack using an
     * Indian-diet food template. Budget-friendly items prioritized for 'low' budget.
     */
    private static function buildMeals(float $totalCalories, string $dietPref, string $budget): array {
        $split = ['breakfast' => 0.25, 'lunch' => 0.35, 'dinner' => 0.30, 'snack' => 0.10];

        $templates = [
            'veg' => [
                'breakfast' => ['Poha with peanuts', 'Vegetable Upma', 'Moong Dal Chilla', 'Oats with milk & fruits'],
                'lunch' => ['Dal, Roti (2), Sabzi, Salad', 'Rajma Chawal with curd', 'Chole with Roti'],
                'dinner' => ['Paneer Bhurji with Roti', 'Khichdi with ghee', 'Mixed vegetable curry with Roti'],
                'snack' => ['Roasted chana', 'Fruit bowl', 'Sprouts chaat'],
            ],
            'non_veg' => [
                'breakfast' => ['Boiled eggs (2) with toast', 'Egg Bhurji with Roti', 'Chicken sandwich'],
                'lunch' => ['Chicken curry with Rice', 'Fish curry with Roti', 'Egg curry with Rice'],
                'dinner' => ['Grilled chicken with salad', 'Chicken soup with Roti', 'Fish fry with vegetables'],
                'snack' => ['Boiled egg', 'Roasted chicken tikka (small)', 'Greek yogurt'],
            ],
            'egg_veg' => [
                'breakfast' => ['Egg omelette with toast', 'Vegetable Upma', 'Moong Dal Chilla'],
                'lunch' => ['Dal, Roti, Sabzi + boiled egg', 'Egg curry with Rice'],
                'dinner' => ['Paneer Bhurji with Roti', 'Egg Bhurji with Roti'],
                'snack' => ['Boiled egg', 'Roasted chana', 'Fruit bowl'],
            ],
            'vegan' => [
                'breakfast' => ['Vegetable Poha', 'Oats with almond milk & fruits', 'Sprouts salad'],
                'lunch' => ['Dal, Roti, Sabzi (no ghee)', 'Chole with Roti', 'Rajma Chawal'],
                'dinner' => ['Tofu Bhurji with Roti', 'Mixed vegetable curry with Roti', 'Khichdi (no ghee)'],
                'snack' => ['Roasted chana', 'Fruit bowl', 'Peanut chaat'],
            ],
        ];

        $tpl = $templates[$dietPref] ?? $templates['veg'];
        $meals = [];

        foreach ($split as $mealType => $ratio) {
            $cal = round($totalCalories * $ratio);
            $options = $tpl[$mealType];
            $item = $options[array_rand($options)];

            $meals[] = [
                'meal_type' => $mealType,
                'food_items' => [$item],
                'calories' => (int) $cal,
                'protein_g' => round($cal * 0.20 / 4, 1),
                'carbs_g' => round($cal * 0.55 / 4, 1),
                'fat_g' => round($cal * 0.25 / 9, 1),
                'est_cost_inr' => $budget === 'low' ? rand(25, 50) : ($budget === 'medium' ? rand(50, 90) : rand(90, 150)),
            ];
        }

        return $meals;
    }
}
