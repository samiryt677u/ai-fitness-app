<?php
require_once __DIR__ . '/../config/db.php';

/**
 * Formula-based workout plan generator using the exercises table.
 * Selects exercises matching goal + fitness_level + location, zero AI cost.
 */
class RuleBasedWorkoutEngine {

    public static function generatePlan(array $profile): array {
        $goal = $profile['goal'] ?? 'maintain_fitness';
        $level = $profile['fitness_level'] ?? 'beginner';
        $location = $profile['workout_location'] === 'both' ? 'home' : ($profile['workout_location'] ?? 'home');
        $equipment = $location === 'gym' ? ['gym', 'none'] : ['home', 'none'];

        $db = DB::conn();
        $placeholders = implode(',', array_fill(0, count($equipment), '?'));

        $stmt = $db->prepare(
            "SELECT * FROM exercises
             WHERE category = ?
             AND equipment IN ($placeholders)
             AND (goal_tag = ? OR goal_tag = 'all')
             ORDER BY RAND()
             LIMIT 6"
        );
        $stmt->execute(array_merge([$level], $equipment, [$goal]));
        $exercises = $stmt->fetchAll();

        if (empty($exercises)) {
            // fallback: any beginner exercises
            $stmt = $db->prepare("SELECT * FROM exercises WHERE category = 'beginner' ORDER BY RAND() LIMIT 6");
            $stmt->execute();
            $exercises = $stmt->fetchAll();
        }

        $totalDuration = 0;
        $totalCalories = 0;
        $planExercises = [];

        foreach ($exercises as $idx => $ex) {
            $sets = $ex['default_sets'] ?? 3;
            $restSec = $ex['rest_seconds'] ?? 60;
            $estMinutes = round(($sets * 45 + $sets * $restSec) / 60); // ~45s work per set assumed

            $totalDuration += $estMinutes;
            $totalCalories += round($estMinutes * ($ex['calories_burned_per_min'] ?? 6));

            $planExercises[] = [
                'exercise_id' => $ex['id'],
                'name' => $ex['name'],
                'sets' => $sets,
                'reps' => $ex['default_reps'] ?? '10-12',
                'rest_seconds' => $restSec,
                'video_url' => $ex['video_url'],
                'sort_order' => $idx,
            ];
        }

        return [
            'location' => $location,
            'est_duration_min' => $totalDuration,
            'est_calories_burn' => (int) $totalCalories,
            'exercises' => $planExercises,
        ];
    }
}
