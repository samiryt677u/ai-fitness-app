<?php
require_once __DIR__ . '/../config/config.php';

/**
 * Thin wrapper around Google Gemini API. Used ONLY for:
 * - AI Chat Coach
 * - Food Photo Analysis (premium)
 * Diet/Workout plans stay rule-based to keep cost near-zero.
 */
class GeminiClient {

    public static function generateText(string $systemPrompt, string $userMessage, int $maxTokens = 500, float $temperature = 0.7): array {
        $url = GEMINI_API_URL . GEMINI_MODEL . ':generateContent?key=' . GEMINI_API_KEY;

        $body = [
            'system_instruction' => ['parts' => [['text' => $systemPrompt]]],
            'contents' => [['role' => 'user', 'parts' => [['text' => $userMessage]]]],
            'generationConfig' => ['maxOutputTokens' => $maxTokens, 'temperature' => $temperature],
        ];

        return self::call($url, $body);
    }

    public static function analyzeImage(string $systemPrompt, string $base64Image, string $mimeType = 'image/jpeg', int $maxTokens = 400): array {
        $url = GEMINI_API_URL . GEMINI_MODEL . ':generateContent?key=' . GEMINI_API_KEY;

        $body = [
            'system_instruction' => ['parts' => [['text' => $systemPrompt]]],
            'contents' => [[
                'role' => 'user',
                'parts' => [
                    ['inline_data' => ['mime_type' => $mimeType, 'data' => $base64Image]],
                    ['text' => 'Analyze this food image as instructed.'],
                ],
            ]],
            'generationConfig' => ['maxOutputTokens' => $maxTokens, 'temperature' => 0.4],
        ];

        return self::call($url, $body);
    }

    private static function call(string $url, array $body, int $retries = 2): array {
        $attempt = 0;
        $lastError = null;

        while ($attempt <= $retries) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
                CURLOPT_POSTFIELDS => json_encode($body),
                CURLOPT_TIMEOUT => 20,
            ]);

            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            curl_close($ch);

            if ($response && $httpCode === 200) {
                $data = json_decode($response, true);
                $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
                $tokens = $data['usageMetadata']['totalTokenCount'] ?? 0;
                return ['success' => true, 'text' => $text, 'tokens' => $tokens];
            }

            $lastError = $curlErr ?: "HTTP $httpCode: $response";
            $attempt++;
            if ($attempt <= $retries) usleep(500000 * $attempt); // backoff: 0.5s, 1s
        }

        return ['success' => false, 'error' => $lastError];
    }
}
