<?php
require_once __DIR__ . '/../config/db.php';

/**
 * Handles XP, streaks, and badge unlocking. Call recordActivity() whenever
 * a user completes a workout, logs diet, water, or sleep.
 */
class GamificationManager {

    private const XP_PER_ACTION = [
        'workout_complete' => 20,
        'diet_logged' => 10,
        'water_goal_met' => 5,
        'sleep_logged' => 5,
        'chat_used' => 2,
    ];

    public static function recordActivity(int $userId, string $action): void {
        $db = DB::conn();
        $xp = self::XP_PER_ACTION[$action] ?? 0;

        $stmt = $db->prepare("SELECT * FROM user_gamification WHERE user_id = ?");
        $stmt->execute([$userId]);
        $g = $stmt->fetch();
        if (!$g) {
            $db->prepare("INSERT INTO user_gamification (user_id) VALUES (?)")->execute([$userId]);
            $stmt->execute([$userId]);
            $g = $stmt->fetch();
        }

        $today = date('Y-m-d');
        $newStreak = $g['current_streak_days'];

        if ($g['last_activity_date'] !== $today) {
            $yesterday = date('Y-m-d', strtotime('-1 day'));
            $newStreak = ($g['last_activity_date'] === $yesterday) ? $g['current_streak_days'] + 1 : 1;
        }

        $newXp = $g['xp_points'] + $xp;
        $newLevel = 1 + intdiv($newXp, 500); // every 500 XP = 1 level
        $longestStreak = max($g['longest_streak_days'], $newStreak);

        $db->prepare(
            "UPDATE user_gamification SET xp_points = ?, level = ?, current_streak_days = ?,
             longest_streak_days = ?, last_activity_date = ? WHERE user_id = ?"
        )->execute([$newXp, $newLevel, $newStreak, $longestStreak, $today, $userId]);

        self::checkBadges($userId, $newXp, $newStreak);
    }

    private static function checkBadges(int $userId, int $xp, int $streak): void {
        $db = DB::conn();
        $badges = $db->query("SELECT * FROM badges")->fetchAll();

        foreach ($badges as $badge) {
            $earned = match ($badge['criteria_type']) {
                'xp' => $xp >= $badge['criteria_value'],
                'streak' => $streak >= $badge['criteria_value'],
                default => false,
            };

            if ($earned) {
                $db->prepare("INSERT IGNORE INTO user_badges (user_id, badge_id) VALUES (?, ?)")
                   ->execute([$userId, $badge['id']]);
            }
        }
    }
}
