# AI Smart Fitness & Diet App — Complete Project

## Folder Structure

- `backend/` — PHP REST API (34 endpoints) + MySQL schema. Deploy to cPanel subdomain.
- `admin/` — Web admin panel (PHP + Bootstrap). Deploy alongside backend.
- `flutter_app/` — Flutter Android app. Build with Flutter SDK.

## Deployment Order

1. **Database**: Import `backend/database/schema.sql` via phpMyAdmin.
2. **Backend**: Upload `backend/` to cPanel, edit `backend/config/config.php` with
   real DB/JWT/SMTP/Gemini/Razorpay credentials.
3. **Admin**: Upload `admin/` next to `backend/`, create first admin user (see
   `admin/README.md`), log in at `/admin/login.php`.
4. **Flutter**: Edit `flutter_app/lib/config/api_config.dart` baseUrl, then
   `flutter build apk --release` for Play Store submission.

## Cost Model (as discussed)

- Diet & Workout plans: 100% rule-based (formula + template driven) — **zero AI cost**.
- AI used only for: Chat Coach + Food Photo Analysis (both credit/premium gated).
- Free users: 5 AI credits/day (configurable). Premium: unlimited.
- Estimated cost at 100 daily active users: ₹0 (Gemini free tier) to ~₹1,500/month worst case.

## What's Functional Right Now

✅ Auth (signup/login/logout/forgot-reset password/email verify)
✅ Profile with BMR/TDEE auto-calculation
✅ Rule-based Diet Plan generator (Indian veg/non-veg/vegan, budget-aware)
✅ Rule-based Workout Plan generator + Smart Workout Mode (timer, auto-advance)
✅ Water & Sleep trackers with suggestions
✅ Daily Health Score (0-100) calculation
✅ Gamification: XP, levels, streaks, badges
✅ AI Chat Coach (Gemini, Hinglish/English, credit-gated)
✅ Food Photo Analysis (Gemini vision, premium-only)
✅ Exercise Library (filterable)
✅ Credit system (daily reset, deduction, refund on AI failure)
✅ Subscription plans + Razorpay checkout (order creation + signature verification)
✅ Admin panel: dashboard, users (block/unblock/grant premium), subscriptions,
   transactions, AdMob control, AI prompt control (live-editable), analytics
✅ AdMob widget helpers (banner/interstitial/rewarded)
✅ Colorful card-based SaaS UI, dark mode support

## What Needs Your Input Before Production

- Real API keys: Gemini, Razorpay, SMTP, AdMob unit IDs
- Firebase project (for AdMob app ID + push notifications later)
- App icon / branding assets
- Play Store developer account + listing assets (screenshots, description)
- Privacy Policy page (required for Play Store — mentions AI processing, ads, payments)
